# Minuta – aplicație Android pentru minute de ședință

Aplicația înregistrează ședința prin microfonul telefonului, transcrie discuția în română și scrie minuta:
**rezumat, decizii, acțiuni (cu responsabil și termen) și transcrierea completă**.

## Ce face

- Înregistrează în fundal, inclusiv cu ecranul stins. Are pauză/continuare și butoane direct în notificare.
- Taie automat audio în bucăți de 10 minute, așa că merge și la ședințe de câteva ore.
- Transcrie în română și scrie minuta, gratuit prin Gemini sau Groq ori, cu plată, prin OpenAI + Claude. Transformă termenele relative („vineri”) în date concrete.
- Poate importa înregistrări existente (meniul ⋮ → *Importă înregistrare*), de exemplu apelurile înregistrate de telefoanele Samsung sau un fișier .m4a/.mp3 trimis de cineva.
- Poți trimite minuta pe e-mail, Teams sau WhatsApp (butonul *Trimite*), o poți copia sau regenera.
- Păstrează istoricul ședințelor pe telefon. Dacă transcrierea se întrerupe (de exemplu fără internet), *Reîncearcă* reia de unde a rămas.

## Ce îți trebuie

Alegi serviciul în ⋮ → **Setări**:

- **Gratuit – Google Gemini (implicit).** Te conectezi cu contul Google pe <https://aistudio.google.com/apikey> → *Create API key*. Gemini face și transcrierea, și minuta. Pe planul gratuit, Google poate folosi datele trimise ca să-și îmbunătățească produsele.
- **Gratuit – Groq.** Cheie de pe <https://console.groq.com/keys>. Transcrierea se face cu Whisper, iar minuta cu un model open-source.
- **Premium (cu plată).** OpenAI pentru transcriere și Claude pentru minută.

## Cum obții APK-ul

### Varianta A – fără să instalezi nimic (GitHub)
1. Fă-ți un cont gratuit pe <https://github.com> și creează un repository nou (poate fi privat).
2. Urcă tot conținutul acestui folder: *Add file → Upload files*, apoi trage fișierele și folderele, inclusiv folderul `.github`.
3. Mergi în tab-ul **Actions**. Build-ul pornește singur și durează cam 5 minute.
4. Când apare bifa verde, deschide rularea și descarcă **Minuta-apk** de la *Artifacts*.
5. Pe telefon: dezarhivează, deschide `app-debug.apk` și permite instalarea din surse necunoscute.

> Dacă browserul nu urcă folderul `.github` (e ascuns), creează-l manual: *Add file → Create new file*, cu numele `.github/workflows/build.yml`, și copiază conținutul fișierului.

### Varianta B – Android Studio
1. Instalează Android Studio, apoi *Open* → alege acest folder.
2. Așteaptă sincronizarea Gradle.
3. Conectează telefonul (cu *USB debugging* activ) și apasă ▶ Run.

## Bine de știut

- **Apeluri Teams / telefon:** Android nu permite aplicațiilor să înregistreze direct sunetul unui apel. Pune apelul pe difuzor lângă telefon sau importă înregistrarea făcută de aplicația de telefon.
- **Baterie:** la unele telefoane (Samsung, Xiaomi) setează *Baterie → Fără restricții* pentru Minuta, ca sistemul să nu oprească înregistrările lungi.
- **Confidențialitate:** audio și transcrierile rămân pe telefon. Audio și textul ajung doar la serviciul ales în Setări (Google, Groq sau OpenAI și Anthropic). Verifică dacă politica firmei permite folosirea acestor servicii pentru ședințele respective.
- **Legal:** anunță participanții că ședința este înregistrată.

## Structura codului

| Fișier | Rol |
|---|---|
| `RecordingService.kt` | Înregistrarea în fundal (serviciu foreground), segmente de 10 min, notificări |
| `Processor.kt` | Transcriere pe segmente + cererea către Claude pentru minută |
| `Api.kt` | Apelurile HTTP către OpenAI și Anthropic, cu reîncercări |
| `Importer.kt` | Importul fișierelor audio și tăierea celor mari |
| `MainActivity.kt` / `RecordActivity.kt` / `MinuteActivity.kt` / `SettingsActivity.kt` | Ecranele |
