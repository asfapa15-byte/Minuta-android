package ro.alex.minuta

import android.content.Context
import android.content.SharedPreferences

/**
 * Three ways to run:
 *  - GEMINI (free, Google account): Gemini transcribes and writes the minute.
 *  - GROQ (free, no card): Whisper transcribes, an open model writes the minute.
 *  - PREMIUM (paid): OpenAI transcribes, Claude writes the minute.
 */
object Prefs {
    const val PROVIDER_GEMINI = "gemini"
    const val PROVIDER_GROQ = "groq"
    const val PROVIDER_PREMIUM = "premium"

    const val DEFAULT_GEMINI_MODEL = "gemini-3.5-flash"

    const val DEFAULT_CLAUDE_MODEL = "claude-sonnet-5-5"
    const val DEFAULT_STT_MODEL = "gpt-4o-transcribe"
    const val DEFAULT_GROQ_STT_MODEL = "whisper-large-v3"
    const val DEFAULT_GROQ_CHAT_MODEL = "openai/gpt-oss-120b"

    private fun p(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)

    private fun str(ctx: Context, key: String) = p(ctx).getString(key, "").orEmpty().trim()

    fun provider(ctx: Context) = when (str(ctx, "provider")) {
        PROVIDER_PREMIUM -> PROVIDER_PREMIUM
        PROVIDER_GROQ -> PROVIDER_GROQ
        else -> PROVIDER_GEMINI
    }

    fun geminiKey(ctx: Context) = str(ctx, "gemini_key")
    fun geminiModel(ctx: Context) = str(ctx, "gemini_model").ifEmpty { DEFAULT_GEMINI_MODEL }

    fun groqKey(ctx: Context) = str(ctx, "groq_key")
    fun groqChatModel(ctx: Context) = str(ctx, "groq_chat_model").ifEmpty { DEFAULT_GROQ_CHAT_MODEL }
    fun groqSttModel(ctx: Context) = str(ctx, "groq_stt_model").ifEmpty { DEFAULT_GROQ_STT_MODEL }

    fun anthropicKey(ctx: Context) = str(ctx, "anthropic_key")
    fun openAiKey(ctx: Context) = str(ctx, "openai_key")
    fun claudeModel(ctx: Context) = str(ctx, "claude_model").ifEmpty { DEFAULT_CLAUDE_MODEL }
    fun sttModel(ctx: Context) = str(ctx, "stt_model").ifEmpty { DEFAULT_STT_MODEL }

    fun context(ctx: Context) = str(ctx, "context")

    fun hasKeys(ctx: Context) = when (provider(ctx)) {
        PROVIDER_GEMINI -> geminiKey(ctx).isNotEmpty()
        PROVIDER_GROQ -> groqKey(ctx).isNotEmpty()
        else -> anthropicKey(ctx).isNotEmpty() && openAiKey(ctx).isNotEmpty()
    }

    fun save(ctx: Context, values: Map<String, String>) {
        val e = p(ctx).edit()
        for ((k, v) in values) e.putString(k, v.trim())
        e.apply()
    }

    fun raw(ctx: Context, key: String) = str(ctx, key)
}
