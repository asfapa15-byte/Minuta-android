package ro.alex.minuta

import android.os.Bundle
import android.view.View
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class SettingsActivity : AppCompatActivity() {

    private lateinit var chatModel: TextInputEditText
    private lateinit var sttModel: TextInputEditText
    private var provider = Prefs.PROVIDER_GEMINI

    // Model fields are kept per service, so switching doesn't mix them up.
    private val models = mutableMapOf<String, String>()

    private fun chatKey(p: String) = when (p) {
        Prefs.PROVIDER_GEMINI -> "gemini_model"
        Prefs.PROVIDER_GROQ -> "groq_chat_model"
        else -> "claude_model"
    }

    private fun sttKey(p: String) = when (p) {
        Prefs.PROVIDER_GROQ -> "groq_stt_model"
        Prefs.PROVIDER_PREMIUM -> "stt_model"
        else -> null // Gemini uses one model for both steps
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val group = findViewById<RadioGroup>(R.id.provider)
        val geminiSection = findViewById<View>(R.id.gemini_section)
        val groqSection = findViewById<View>(R.id.free_section)
        val premiumSection = findViewById<View>(R.id.premium_section)
        val gemini = findViewById<TextInputEditText>(R.id.gemini_key)
        val groq = findViewById<TextInputEditText>(R.id.groq_key)
        val anthropic = findViewById<TextInputEditText>(R.id.anthropic_key)
        val openai = findViewById<TextInputEditText>(R.id.openai_key)
        val context = findViewById<TextInputEditText>(R.id.context)
        val chatLayout = findViewById<TextInputLayout>(R.id.chat_model_layout)
        val sttLayout = findViewById<TextInputLayout>(R.id.stt_model_layout)
        chatModel = findViewById(R.id.chat_model)
        sttModel = findViewById(R.id.stt_model)

        for (k in listOf("gemini_model", "groq_chat_model", "groq_stt_model", "claude_model", "stt_model")) {
            models[k] = Prefs.raw(this, k)
        }
        gemini.setText(Prefs.geminiKey(this))
        groq.setText(Prefs.groqKey(this))
        anthropic.setText(Prefs.anthropicKey(this))
        openai.setText(Prefs.openAiKey(this))
        context.setText(Prefs.context(this))

        fun show(p: String) {
            provider = p
            geminiSection.visibility = if (p == Prefs.PROVIDER_GEMINI) View.VISIBLE else View.GONE
            groqSection.visibility = if (p == Prefs.PROVIDER_GROQ) View.VISIBLE else View.GONE
            premiumSection.visibility = if (p == Prefs.PROVIDER_PREMIUM) View.VISIBLE else View.GONE
            chatLayout.hint = if (p == Prefs.PROVIDER_GEMINI) "Model Gemini" else "Model pentru minută"
            chatLayout.helperText = "Implicit: " + when (p) {
                Prefs.PROVIDER_GEMINI -> Prefs.DEFAULT_GEMINI_MODEL
                Prefs.PROVIDER_GROQ -> Prefs.DEFAULT_GROQ_CHAT_MODEL
                else -> Prefs.DEFAULT_CLAUDE_MODEL
            }
            chatModel.setText(models[chatKey(p)].orEmpty())
            val stt = sttKey(p)
            sttLayout.visibility = if (stt == null) View.GONE else View.VISIBLE
            if (stt != null) {
                sttLayout.helperText = "Implicit: " +
                    if (p == Prefs.PROVIDER_GROQ) Prefs.DEFAULT_GROQ_STT_MODEL else Prefs.DEFAULT_STT_MODEL
                sttModel.setText(models[stt].orEmpty())
            }
        }

        val current = Prefs.provider(this)
        group.check(
            when (current) {
                Prefs.PROVIDER_GEMINI -> R.id.provider_gemini
                Prefs.PROVIDER_GROQ -> R.id.provider_free
                else -> R.id.provider_premium
            }
        )
        show(current)
        group.setOnCheckedChangeListener { _, checkedId ->
            rememberModels()
            show(
                when (checkedId) {
                    R.id.provider_gemini -> Prefs.PROVIDER_GEMINI
                    R.id.provider_free -> Prefs.PROVIDER_GROQ
                    else -> Prefs.PROVIDER_PREMIUM
                }
            )
        }

        findViewById<MaterialButton>(R.id.save).setOnClickListener {
            rememberModels()
            val values = mutableMapOf(
                "provider" to provider,
                "gemini_key" to gemini.text?.toString().orEmpty(),
                "groq_key" to groq.text?.toString().orEmpty(),
                "anthropic_key" to anthropic.text?.toString().orEmpty(),
                "openai_key" to openai.text?.toString().orEmpty(),
                "context" to context.text?.toString().orEmpty(),
            )
            values.putAll(models)
            Prefs.save(this, values)
            Toast.makeText(this, "Setările au fost salvate", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun rememberModels() {
        models[chatKey(provider)] = chatModel.text?.toString().orEmpty()
        sttKey(provider)?.let { models[it] = sttModel.text?.toString().orEmpty() }
    }
}
