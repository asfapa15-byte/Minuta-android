package ro.alex.minuta

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** Turns a meeting's audio into a transcript, then into a minute. */
object Processor {
    private val running = mutableSetOf<String>()

    fun isRunning(id: String): Boolean = synchronized(running) { id in running }

    suspend fun process(ctx: Context, id: String) {
        withContext(Dispatchers.IO) { processBlocking(ctx, id) }
    }

    private fun processBlocking(ctx: Context, id: String) {
        val first = synchronized(running) { running.add(id) }
        if (first) {
            try {
                run(ctx, id)
            } catch (e: Exception) {
                val msg = when (e) {
                    is ApiException -> e.message
                    is IOException -> "Problemă de conexiune: ${e.message ?: "fără internet?"}"
                    else -> e.message ?: e.javaClass.simpleName
                }
                MeetingRepo.update(ctx, id) { it.status = Status.ERROR; it.error = msg }
            } finally {
                synchronized(running) { running.remove(id) }
            }
        }
    }

    private fun run(ctx: Context, id: String) {
        val provider = Prefs.provider(ctx)
        if (!Prefs.hasKeys(ctx)) {
            MeetingRepo.update(ctx, id) {
                it.status = Status.ERROR
                it.error = when (provider) {
                    Prefs.PROVIDER_GEMINI -> "Lipsește cheia Gemini. Completează-o în Setări, apoi apasă Reîncearcă."
                    Prefs.PROVIDER_GROQ -> "Lipsește cheia Groq. Completează-o în Setări, apoi apasă Reîncearcă."
                    else -> "Lipsesc cheile API. Completează-le în Setări, apoi apasă Reîncearcă."
                }
            }
            return
        }

        // 1. Transcribe every audio part not transcribed yet.
        val start = MeetingRepo.update(ctx, id) { it.status = Status.TRANSCRIBING; it.error = null } ?: return
        val dir = MeetingRepo.dir(ctx, id)
        var previous = ""
        for (seg in start.segments) {
            val done = start.segmentTranscripts[seg]
            if (done != null) {
                previous = done
                continue
            }
            val f = File(dir, seg)
            val prompt = sttPrompt(start, previous)
            val text = if (!f.exists() || f.length() < 2_000) "" else Api.withRetry {
                when (provider) {
                    Prefs.PROVIDER_GEMINI -> cleanGemini(
                        Api.geminiTranscribe(Prefs.geminiKey(ctx), Prefs.geminiModel(ctx), f, geminiSttPrompt(start, previous))
                    )
                    Prefs.PROVIDER_GROQ ->
                        Api.transcribe(Api.GROQ_STT_URL, "Groq", f, Prefs.groqKey(ctx), Prefs.groqSttModel(ctx), prompt)
                    else ->
                        Api.transcribe(Api.OPENAI_STT_URL, "OpenAI", f, Prefs.openAiKey(ctx), Prefs.sttModel(ctx), prompt)
                }
            }
            MeetingRepo.update(ctx, id) { it.segmentTranscripts[seg] = text }
            if (text.isNotBlank()) previous = text
        }

        val m = MeetingRepo.update(ctx, id) { mm ->
            mm.transcript = mm.segments.mapNotNull { mm.segmentTranscripts[it] }
                .filter { it.isNotBlank() }.joinToString("\n\n")
            mm.status = Status.SUMMARIZING
        } ?: return
        if (m.transcript.isBlank()) {
            MeetingRepo.update(ctx, id) {
                it.status = Status.ERROR
                it.error = "Nu s-a detectat vorbire în înregistrare."
            }
            return
        }

        // 2. Write the minute.
        val answer = when (provider) {
            Prefs.PROVIDER_GEMINI -> Api.withRetry {
                Api.geminiText(Prefs.geminiKey(ctx), Prefs.geminiModel(ctx), systemPrompt(ctx), userPrompt(m, "TRANSCRIERE", m.transcript), true)
            }
            Prefs.PROVIDER_GROQ -> freeMinute(ctx, m)
            else -> Api.withRetry {
                Api.claude(Prefs.anthropicKey(ctx), Prefs.claudeModel(ctx), systemPrompt(ctx), userPrompt(m, "TRANSCRIERE", m.transcript))
            }
        }
        val json = parseJson(answer)
        MeetingRepo.update(ctx, id) { mm ->
            if (mm.title.isBlank()) mm.title = json.optString("title", "").trim()
            mm.summary = json.optString("summary", "").trim()
            mm.decisions.clear()
            json.optJSONArray("decisions")?.let { a ->
                for (i in 0 until a.length()) a.optString(i).trim().takeIf { it.isNotEmpty() }?.let { mm.decisions.add(it) }
            }
            mm.actions.clear()
            json.optJSONArray("actions")?.let { a ->
                for (i in 0 until a.length()) {
                    val x = a.optJSONObject(i) ?: continue
                    val task = x.optString("task").trim()
                    if (task.isEmpty()) continue
                    mm.actions.add(
                        ActionItem(
                            task,
                            x.optString("owner").trim().ifEmpty { "Nestabilit" },
                            x.optString("due").trim().ifEmpty { "Nestabilit" },
                        )
                    )
                }
            }
            mm.status = Status.DONE
            mm.error = null
        }
    }

    /** Free plan allows ~8K tokens per minute, so long meetings are summarised part by part. */
    private const val CHUNK_CHARS = 9_000
    private const val FREE_PAUSE_MS = 45_000L

    private fun freeChat(ctx: Context, user: String): String = Api.withRetry {
        Api.chat(Api.GROQ_CHAT_URL, "Groq", Prefs.groqKey(ctx), Prefs.groqChatModel(ctx), systemPrompt(ctx), user)
    }

    private fun freeMinute(ctx: Context, m: Meeting): String {
        if (m.transcript.length <= CHUNK_CHARS) {
            return freeChat(ctx, userPrompt(m, "TRANSCRIERE", m.transcript))
        }
        val chunks = splitText(m.transcript, CHUNK_CHARS)
        val notes = StringBuilder()
        chunks.forEachIndexed { i, chunk ->
            if (i > 0) Thread.sleep(FREE_PAUSE_MS)
            val part = freeChat(ctx, notesPrompt(m, i + 1, chunks.size, chunk))
            notes.append("PARTEA ").append(i + 1).append(":\n").append(part.trim()).append("\n\n")
        }
        Thread.sleep(FREE_PAUSE_MS)
        return freeChat(ctx, userPrompt(m, "NOTIȚE DIN FIECARE PARTE A ȘEDINȚEI (în ordine)", notes.toString()))
    }

    private fun splitText(text: String, max: Int): List<String> {
        val out = mutableListOf<String>()
        var rest = text
        while (rest.length > max) {
            var cut = rest.lastIndexOf(". ", max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut < max / 2) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1)
        }
        if (rest.isNotBlank()) out.add(rest.trim())
        return out
    }

    private fun notesPrompt(m: Meeting, n: Int, total: Int, chunk: String): String = buildString {
        append("Data ședinței: ").append(Format.longDate(m.createdAt)).append('\n')
        append("Participanți declarați: ").append(m.participants.ifBlank { "(nespecificați)" }).append("\n\n")
        append("Mai jos este partea $n din $total a transcrierii automate a unei ședințe (poate avea greșeli de recunoaștere vocală). ")
        append("Extrage notițe concise. Răspunde DOAR cu JSON, fără alt text, cu forma: ")
        append("{\"points\": [\"subiect discutat\"], \"decisions\": [\"decizie\"], \"actions\": [{\"task\": \"ce\", \"owner\": \"cine sau Nestabilit\", \"due\": \"termen sau Nestabilit\"}]}")
        append("\n\nTRANSCRIERE (partea $n):\n").append(chunk)
    }

    private fun geminiSttPrompt(m: Meeting, previous: String): String = buildString {
        append("Transcrie fidel, cuvânt cu cuvânt, în limba română, vorbirea din acest fragment audio al unei ședințe de lucru. ")
        append("Scrie doar textul rostit, cu punctuație corectă, împărțit în paragrafe. ")
        append("Nu rezuma, nu adăuga comentarii, titluri sau marcaje de timp. ")
        append("Dacă în fragment nu se vorbește deloc, răspunde exact cu: [LINISTE]")
        if (m.participants.isNotBlank()) append("\nParticipanți (pentru scrierea corectă a numelor): ").append(m.participants)
        if (m.title.isNotBlank()) append("\nSubiectul ședinței: ").append(m.title)
        if (previous.isNotBlank()) append("\nFinalul fragmentului anterior, pentru context: ").append(previous.takeLast(200))
    }

    private fun cleanGemini(text: String): String {
        val t = text.trim().removePrefix("```").removeSuffix("```").trim()
        return if (t.contains("[LINISTE]") && t.length < 40) "" else t
    }

    private fun sttPrompt(m: Meeting, previous: String): String {
        val sb = StringBuilder("Ședință de lucru în limba română.")
        if (m.title.isNotBlank()) sb.append(" Subiect: ").append(m.title).append('.')
        if (m.participants.isNotBlank()) sb.append(" Participanți: ").append(m.participants).append('.')
        if (previous.isNotBlank()) sb.append(' ').append(previous.takeLast(200))
        return sb.toString()
    }

    private fun systemPrompt(ctx: Context): String {
        val extra = Prefs.context(ctx)
        return buildString {
            append("Ești un secretar de ședință atent și concis. Redactezi minute de ședință în limba română, ")
            append("clare, factuale, fără să inventezi nimic ce nu reiese din discuție.")
            if (extra.isNotEmpty()) append("\nContextul echipei: ").append(extra)
        }
    }

    private fun userPrompt(m: Meeting, label: String, material: String): String = buildString {
        append("Data ședinței: ").append(Format.longDate(m.createdAt)).append('\n')
        append("Subiect declarat: ").append(m.title.ifBlank { "(nespecificat – propune unul scurt)" }).append('\n')
        append("Participanți declarați: ").append(m.participants.ifBlank { "(nespecificați)" }).append("\n\n")
        append(
            """
            Mai jos este materialul ședinței (transcriere automată sau notițe extrase din ea). Poate conține greșeli de recunoaștere vocală și nu indică cine vorbește.
            Scrie minuta și răspunde DOAR cu un obiect JSON valid, fără alt text și fără ```, exact cu forma:
            {"title": "subiect scurt", "summary": "rezumat în 3-6 propoziții", "decisions": ["decizie"], "actions": [{"task": "ce trebuie făcut", "owner": "responsabil", "due": "termen"}]}
            Reguli:
            - Include doar decizii și acțiuni care reies clar din discuție; dacă nu există, folosește liste goale.
            - Dacă responsabilul sau termenul nu reies clar, scrie "Nestabilit".
            - Transformă termenele relative („vineri”, „săptămâna viitoare”) în date concrete, pornind de la data ședinței, de ex. „vineri, 28 noiembrie”.
            - Corectează numele și termenii tehnici evident greșit transcriși.
            """.trimIndent()
        )
        append("\n\n").append(label).append(":\n").append(material)
    }

    private fun parseJson(text: String): JSONObject {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("Răspuns neașteptat de la modelul AI. Apasă Reîncearcă.")
        return try {
            JSONObject(text.substring(s, e + 1))
        } catch (ex: Exception) {
            throw IOException("Răspuns neașteptat de la modelul AI. Apasă Reîncearcă.")
        }
    }
}
