package ro.alex.minuta

import android.os.Bundle
import android.view.View
import android.widget.RadioGroup
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class SettingsActivity : LockedActivity() {

    private lateinit var chatModel: TextInputEditText
    private lateinit var sttModel: TextInputEditText
    private var provider = Prefs.PROVIDER_GEMINI

    // Model fields are kept per service, so switching doesn't mix them up.
    private val models = mutableMapOf<String, String>()

    private fun chatKey(p: String) = when (p) {
        Prefs.PROVIDER_GEMINI -> "gemini_model"
        Prefs.PROVIDER_GROQ -> "groq_chat_model"
        else -> "claude_model"
    }

    private fun sttKey(p: String) = when (p) {
        Prefs.PROVIDER_GROQ -> "groq_stt_model"
        Prefs.PROVIDER_PREMIUM -> "stt_model"
        else -> null // Gemini uses one model for both steps
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        val group = findViewById<RadioGroup>(R.id.provider)
        val geminiSection = findViewById<View>(R.id.gemini_section)
        val groqSection = findViewById<View>(R.id.free_section)
        val premiumSection = findViewById<View>(R.id.premium_section)
        val gemini = findViewById<TextInputEditText>(R.id.gemini_key)
        val groq = findViewById<TextInputEditText>(R.id.groq_key)
        val anthropic = findViewById<TextInputEditText>(R.id.anthropic_key)
        val openai = findViewById<TextInputEditText>(R.id.openai_key)
        val context = findViewById<TextInputEditText>(R.id.context)
        val emailEnabled = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.email_enabled)
        val emailSection = findViewById<View>(R.id.email_section)
        val gmail = findViewById<TextInputEditText>(R.id.gmail_address)
        val gmailPass = findViewById<TextInputEditText>(R.id.gmail_app_password)
        val lock = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.lock_enabled)
        val senderName = findViewById<TextInputEditText>(R.id.sender_name)
        val myAddress = findViewById<TextInputEditText>(R.id.my_address)
        val signature = findViewById<TextInputEditText>(R.id.signature)
        val teamContacts = findViewById<TextInputEditText>(R.id.team_contacts)
        val review = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.review_before_send)
        val tasksPerPerson = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.tasks_per_person)
        val weekly = findViewById<com.google.android.material.materialswitch.MaterialSwitch>(R.id.weekly_digest)
        val defSpoken = findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.default_spoken)
        val defMinute = findViewById<com.google.android.material.button.MaterialButtonToggleGroup>(R.id.default_minute)
        val chatLayout = findViewById<TextInputLayout>(R.id.chat_model_layout)
        val sttLayout = findViewById<TextInputLayout>(R.id.stt_model_layout)
        chatModel = findViewById(R.id.chat_model)
        sttModel = findViewById(R.id.stt_model)

        for (k in listOf("gemini_model", "groq_chat_model", "groq_stt_model", "claude_model", "stt_model")) {
            models[k] = Prefs.raw(this, k)
        }
        gemini.setText(Prefs.geminiKey(this))
        groq.setText(Prefs.groqKey(this))
        anthropic.setText(Prefs.anthropicKey(this))
        openai.setText(Prefs.openAiKey(this))
        context.setText(Prefs.context(this))
        gmail.setText(Prefs.raw(this, "gmail_address"))
        gmailPass.setText(Prefs.raw(this, "gmail_app_password"))
        emailEnabled.isChecked = Prefs.raw(this, "email_enabled") == "1"
        emailSection.visibility = if (emailEnabled.isChecked) View.VISIBLE else View.GONE
        emailEnabled.setOnCheckedChangeListener { _, on -> emailSection.visibility = if (on) View.VISIBLE else View.GONE }

        senderName.setText(Prefs.raw(this, "sender_name"))
        myAddress.setText(Prefs.myAddress(this))
        signature.setText(Prefs.signature(this))
        teamContacts.setText(Prefs.raw(this, "team_contacts"))
        review.isChecked = Prefs.reviewBeforeSend(this)
        tasksPerPerson.isChecked = Prefs.tasksPerPerson(this)
        weekly.isChecked = Prefs.weeklyDigest(this)
        defSpoken.check(
            when (Prefs.defaultSpokenLang(this)) {
                "en" -> R.id.def_spoken_en
                "auto" -> R.id.def_spoken_auto
                else -> R.id.def_spoken_ro
            }
        )
        defMinute.check(if (Prefs.defaultMinuteLang(this) == "en") R.id.def_minute_en else R.id.def_minute_ro)

        lock.isChecked = AppLock.enabled(this)
        lock.setOnCheckedChangeListener { sw, on ->
            if (on && !AppLock.available(this)) {
                sw.isChecked = false
                Toast.makeText(this, "Setează întâi o blocare a ecranului (amprentă/PIN) în setările telefonului.", Toast.LENGTH_LONG).show()
            }
        }

        fun emailValues() = mapOf(
            "email_enabled" to if (emailEnabled.isChecked) "1" else "",
            "gmail_address" to gmail.text?.toString().orEmpty().trim(),
            "gmail_app_password" to gmailPass.text?.toString().orEmpty().replace(" ", ""),
            "sender_name" to senderName.text?.toString().orEmpty().trim(),
            "my_address" to myAddress.text?.toString().orEmpty().trim(),
            "review_before_send" to if (review.isChecked) "1" else "0",
            "tasks_per_person" to if (tasksPerPerson.isChecked) "1" else "0",
            "weekly_digest" to if (weekly.isChecked) "1" else "0",
        )

        findViewById<MaterialButton>(R.id.email_test).setOnClickListener { btn ->
            Prefs.save(this, emailValues())
            Prefs.saveRaw(this, "signature", signature.text?.toString().orEmpty().trim())
            if (!Mailer.ready(this)) {
                Toast.makeText(this, "Completează adresa Gmail și parola de aplicație.", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            btn.isEnabled = false
            Toast.makeText(this, "Se trimite…", Toast.LENGTH_SHORT).show()
            lifecycleScope.launch {
                val err = withContext(Dispatchers.IO) { Mailer.sendTest(applicationContext) }
                btn.isEnabled = true
                Toast.makeText(
                    this@SettingsActivity,
                    err ?: "Trimis! Verifică inboxul adresei ${myAddress.text?.toString().orEmpty().ifBlank { gmail.text.toString() }}.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

        fun show(p: String) {
            provider = p
            geminiSection.visibility = if (p == Prefs.PROVIDER_GEMINI) View.VISIBLE else View.GONE
            groqSection.visibility = if (p == Prefs.PROVIDER_GROQ) View.VISIBLE else View.GONE
            premiumSection.visibility = if (p == Prefs.PROVIDER_PREMIUM) View.VISIBLE else View.GONE
            chatLayout.hint = if (p == Prefs.PROVIDER_GEMINI) "Model Gemini" else "Model pentru minută"
            chatLayout.helperText = "Implicit: " + when (p) {
                Prefs.PROVIDER_GEMINI -> Prefs.DEFAULT_GEMINI_MODEL
                Prefs.PROVIDER_GROQ -> Prefs.DEFAULT_GROQ_CHAT_MODEL
                else -> Prefs.DEFAULT_CLAUDE_MODEL
            }
            chatModel.setText(models[chatKey(p)].orEmpty())
            val stt = sttKey(p)
            sttLayout.visibility = if (stt == null) View.GONE else View.VISIBLE
            if (stt != null) {
                sttLayout.helperText = "Implicit: " +
                    if (p == Prefs.PROVIDER_GROQ) Prefs.DEFAULT_GROQ_STT_MODEL else Prefs.DEFAULT_STT_MODEL
                sttModel.setText(models[stt].orEmpty())
            }
        }

        val current = Prefs.provider(this)
        group.check(
            when (current) {
                Prefs.PROVIDER_GEMINI -> R.id.provider_gemini
                Prefs.PROVIDER_GROQ -> R.id.provider_free
                else -> R.id.provider_premium
            }
        )
        show(current)
        group.setOnCheckedChangeListener { _, checkedId ->
            rememberModels()
            show(
                when (checkedId) {
                    R.id.provider_gemini -> Prefs.PROVIDER_GEMINI
                    R.id.provider_free -> Prefs.PROVIDER_GROQ
                    else -> Prefs.PROVIDER_PREMIUM
                }
            )
        }

        findViewById<MaterialButton>(R.id.save).setOnClickListener {
            rememberModels()
            val values = mutableMapOf(
                "provider" to provider,
                "gemini_key" to gemini.text?.toString().orEmpty(),
                "groq_key" to groq.text?.toString().orEmpty(),
                "anthropic_key" to anthropic.text?.toString().orEmpty(),
                "openai_key" to openai.text?.toString().orEmpty(),
                "context" to context.text?.toString().orEmpty(),
            )
            values.putAll(models)
            values.putAll(emailValues())
            values["lock_enabled"] = if (lock.isChecked) "1" else ""
            values["default_spoken_lang"] = when (defSpoken.checkedButtonId) {
                R.id.def_spoken_en -> "en"
                R.id.def_spoken_auto -> "auto"
                else -> "ro"
            }
            values["default_minute_lang"] = if (defMinute.checkedButtonId == R.id.def_minute_en) "en" else "ro"
            Prefs.saveRaw(this, "signature", signature.text?.toString().orEmpty().trim())
            Prefs.saveRaw(this, "team_contacts", teamContacts.text?.toString().orEmpty().trim())
            if (lock.isChecked) AppLock.unlocked = true
            Prefs.save(this, values)
            Toast.makeText(this, "Setările au fost salvate", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun rememberModels() {
        models[chatKey(provider)] = chatModel.text?.toString().orEmpty()
        sttKey(provider)?.let { models[it] = sttModel.text?.toString().orEmpty() }
    }
}
