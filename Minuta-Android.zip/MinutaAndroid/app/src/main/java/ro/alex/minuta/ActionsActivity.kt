package ro.alex.minuta

import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.appbar.MaterialToolbar
import kotlinx.coroutines.launch

/** Every action from every meeting, by deadline. Tick them off as they get done. */
class ActionsActivity : LockedActivity() {

    private lateinit var content: LinearLayout
    private var showDone = false
    private var byPerson = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_minute)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = "Acțiuni"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }
        content = findViewById(R.id.content)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                MeetingRepo.changes.collect { render() }
            }
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun tv(s: String, style: Int, color: Int? = null, top: Int = 0) = TextView(this).apply {
        setTextAppearance(style)
        text = s
        color?.let { setTextColor(it) }
        setPadding(0, dp(top), 0, 0)
    }

    private fun render() {
        content.removeAllViews()
        val today = Format.todayIso()
        val weekEnd = Format.todayIso(7)
        val all = MeetingRepo.all(this).filter { it.status == Status.DONE }
            .flatMap { m -> m.actions.map { m to it } }
            .filter { showDone || !it.second.done }

        val open = all.count { !it.second.done }
        content.addView(
            tv(
                if (open == 0) "Nicio acțiune deschisă." else "$open acțiuni deschise",
                com.google.android.material.R.style.TextAppearance_Material3_HeadlineSmall,
            )
        )
        content.addView(
            tv(
                "Bifează o acțiune când e gata. Primești o notificare dimineața pentru termenele de azi și de mâine.",
                com.google.android.material.R.style.TextAppearance_Material3_BodyMedium,
                ContextCompat.getColor(this, R.color.muted), 4,
            )
        )

        val groups: List<Pair<String, List<Pair<Meeting, ActionItem>>>> = if (byPerson) {
            all.groupBy { it.second.owner.ifBlank { "Nestabilit" } }.toSortedMap().map { (k, v) ->
                k to v.sortedBy { it.second.dueDate.ifEmpty { "9999" } }
            }
        } else {
            fun bucket(a: ActionItem) = when {
                a.done -> 5
                a.dueDate.isEmpty() -> 4
                a.dueDate < today -> 0
                a.dueDate == today -> 1
                a.dueDate <= weekEnd -> 2
                else -> 3
            }
            val names = listOf("Întârziate", "Azi", "În următoarele 7 zile", "Mai târziu", "Fără termen", "Gata")
            all.groupBy { bucket(it.second) }.toSortedMap().map { (k, v) ->
                names[k] to v.sortedBy { it.second.dueDate.ifEmpty { "9999" } }
            }
        }

        for ((title, items) in groups) {
            val color = if (title == "Întârziate") R.color.error else R.color.teal
            content.addView(
                tv("$title (${items.size})", com.google.android.material.R.style.TextAppearance_Material3_TitleMedium,
                    ContextCompat.getColor(this, color), 22)
            )
            for ((m, a) in items) content.addView(row(m, a))
        }
    }

    private fun row(m: Meeting, a: ActionItem): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(8), 0, dp(4))
            isClickable = true
            setOnClickListener { startActivity(MinuteActivity.intent(this@ActionsActivity, m.id)) }
        }
        val check = CheckBox(this).apply {
            isChecked = a.done
            contentDescription = "Gata"
            setOnCheckedChangeListener { _, on ->
                MeetingRepo.update(this@ActionsActivity, m.id) { mm -> mm.actions.firstOrNull { it.id == a.id }?.done = on }
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(tv(a.task, com.google.android.material.R.style.TextAppearance_Material3_BodyLarge).apply {
            alpha = if (a.done) 0.5f else 1f
        })
        val who = if (byPerson) "" else "${a.owner} · "
        texts.addView(
            tv("$who${a.due} · ${m.displayTitle()}", com.google.android.material.R.style.TextAppearance_Material3_BodySmall,
                ContextCompat.getColor(this, R.color.muted))
        )
        box.addView(check)
        box.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return box
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "Grupează pe persoane").setCheckable(true).isChecked = byPerson
        menu.add(0, 2, 1, "Arată și cele bifate").setCheckable(true).isChecked = showDone
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        1 -> {
            byPerson = !byPerson
            item.isChecked = byPerson
            render()
            true
        }
        2 -> {
            showDone = !showDone
            item.isChecked = showDone
            render()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}
