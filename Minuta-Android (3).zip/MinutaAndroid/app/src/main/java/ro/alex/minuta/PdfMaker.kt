package ro.alex.minuta

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import java.io.ByteArrayOutputStream
import java.io.File

/** Builds a clean A4 PDF of the minute with the phone's own PDF engine (no library). */
object PdfMaker {
    private const val W = 595
    private const val H = 842
    private const val M = 50f
    private const val CONTENT_W = W - 2 * M
    private const val BOTTOM = H - 56f

    private val TEAL = Color.rgb(11, 93, 99)
    private val INK = Color.rgb(20, 22, 26)
    private val MUTED = Color.rgb(91, 98, 104)
    private val RULE = Color.rgb(223, 229, 230)
    private val TINT = Color.rgb(230, 241, 241)

    fun fileName(m: Meeting): String {
        val base = java.text.Normalizer.normalize(m.displayTitle(), java.text.Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "").replace(Regex("[^A-Za-z0-9]+"), "-").trim('-').take(50)
        return "Minuta-${base.ifEmpty { "sedinta" }}-${Format.shortDate(m.createdAt).replace('.', '-')}.pdf"
    }

    /** Writes the PDF to the cache folder, for sharing. */
    fun makeFile(ctx: Context, m: Meeting): File {
        val dir = File(ctx.cacheDir, "pdf").apply { mkdirs() }
        val f = File(dir, fileName(m))
        f.writeBytes(make(ctx, m))
        return f
    }

    fun make(ctx: Context, m: Meeting): ByteArray {
        val l = m.labels()
        val doc = PdfDocument()
        val w = Writer(doc, m.displayTitle(), l)

        fun paint(size: Float, color: Int, bold: Boolean = false) = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size
            this.color = color
            typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val title = paint(20f, TEAL, true)
        val meta = paint(10f, MUTED)
        val head = paint(13f, TEAL, true)
        val body = paint(10.5f, INK)
        val small = paint(9f, MUTED)
        val cellHead = paint(9.5f, TEAL, true)

        w.text(m.displayTitle(), title, after = 4f)
        val metaLine = mutableListOf(Format.date(m.createdAt, m.minuteLang))
        if (m.durationMs > 0) metaLine.add(l.duration.lowercase() + " " + Format.duration(m.durationMs))
        w.text(metaLine.joinToString(" · "), meta, after = 2f)
        if (m.participants.isNotBlank()) w.text("${l.participants}: ${m.participants}", meta, after = 2f)
        w.rule(TEAL, 1.2f, before = 8f, after = 4f)

        w.heading(l.summary, head)
        w.text(m.summary.ifBlank { "—" }, body)

        w.heading(l.decisions, head)
        if (m.decisions.isEmpty()) w.text(l.noDecisions, small)
        for (d in m.decisions) w.text("•  $d", body, after = 3f, indent = 0f)

        w.heading(l.actions, head)
        if (m.actions.isEmpty()) {
            w.text(l.noActions, small)
        } else {
            val cols = floatArrayOf(0.56f, 0.24f, 0.20f)
            w.row(listOf(l.action, l.owner, l.due), cols, cellHead, TINT)
            for (a in m.actions) w.row(listOf(a.task, a.owner, a.due), cols, body, null)
        }

        if (m.photos.isNotEmpty()) {
            w.heading(l.photos, head)
            val dir = MeetingRepo.dir(ctx, m.id)
            for (p in m.photos) {
                val bmp = ImageUtil.load(File(dir, p), 1400) ?: continue
                w.image(bmp)
                bmp.recycle()
            }
        }

        if (m.transcript.isNotBlank()) {
            w.heading(l.transcript, head)
            for (para in m.transcript.split("\n\n")) {
                if (para.isNotBlank()) w.text(para.trim(), paint(9f, Color.rgb(61, 67, 72)), after = 5f)
            }
        }

        w.finish()
        val out = ByteArrayOutputStream()
        doc.writeTo(out)
        doc.close()
        return out.toByteArray()
    }

    private class Writer(private val doc: PdfDocument, private val title: String, private val l: Labels) {
        private var page: PdfDocument.Page? = null
        private lateinit var canvas: Canvas
        private var y = M
        private var pageNo = 0
        private val footer = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8f; color = MUTED }

        init {
            newPage()
        }

        private fun newPage() {
            closePage()
            pageNo++
            val p = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            page = p
            canvas = p.canvas
            y = M
        }

        private fun closePage() {
            val p = page ?: return
            val text = "${l.minute} · ${title.take(60)}"
            canvas.drawText(text, M, H - 30f, footer)
            val num = pageNo.toString()
            canvas.drawText(num, W - M - footer.measureText(num), H - 30f, footer)
            doc.finishPage(p)
            page = null
        }

        fun finish() = closePage()

        private fun layout(text: String, paint: TextPaint, width: Float): StaticLayout =
            StaticLayout.Builder.obtain(text, 0, text.length, paint, width.toInt())
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.15f)
                .setIncludePad(false)
                .build()

        /** Draws text, splitting it across pages when needed. */
        fun text(s: String, paint: TextPaint, after: Float = 6f, indent: Float = 0f) {
            val lay = layout(s, paint, CONTENT_W - indent)
            var line = 0
            while (line < lay.lineCount) {
                val top = lay.getLineTop(line)
                var last = line
                while (last + 1 < lay.lineCount && lay.getLineBottom(last + 1) - top <= BOTTOM - y) last++
                val height = (lay.getLineBottom(last) - top).toFloat()
                if (height > BOTTOM - y && y > M + 1f) {
                    newPage()
                    continue
                }
                canvas.save()
                canvas.translate(M + indent, y - top)
                canvas.clipRect(0f, top.toFloat(), CONTENT_W, lay.getLineBottom(last).toFloat())
                lay.draw(canvas)
                canvas.restore()
                y += height
                line = last + 1
                if (line < lay.lineCount) newPage()
            }
            y += after
        }

        fun heading(s: String, paint: TextPaint) {
            if (BOTTOM - y < 60f) newPage() else y += 12f
            text(s, paint, after = 5f)
        }

        fun rule(color: Int, width: Float, before: Float, after: Float) {
            y += before
            val p = Paint().apply { this.color = color; strokeWidth = width }
            canvas.drawLine(M, y, W - M, y, p)
            y += after
        }

        /** One table row; columns as fractions of the page width. */
        fun row(cells: List<String>, cols: FloatArray, paint: TextPaint, background: Int?) {
            val pad = 5f
            val lays = cells.mapIndexed { i, c -> layout(c, paint, CONTENT_W * cols[i] - 2 * pad) }
            val h = (lays.maxOf { it.height } + 2 * pad)
            if (y + h > BOTTOM) newPage()
            if (background != null) {
                canvas.drawRect(RectF(M, y, W - M, y + h), Paint().apply { color = background })
            }
            var x = M
            for ((i, lay) in lays.withIndex()) {
                canvas.save()
                canvas.translate(x + pad, y + pad)
                lay.draw(canvas)
                canvas.restore()
                x += CONTENT_W * cols[i]
            }
            y += h
            canvas.drawLine(M, y, W - M, y, Paint().apply { color = RULE; strokeWidth = 0.7f })
        }

        fun image(bmp: android.graphics.Bitmap) {
            val maxH = BOTTOM - M
            var dw = CONTENT_W
            var dh = bmp.height * dw / bmp.width
            if (dh > maxH) {
                dh = maxH
                dw = bmp.width * dh / bmp.height
            }
            if (y + dh > BOTTOM) newPage()
            canvas.drawBitmap(bmp, null, RectF(M, y, M + dw, y + dh), Paint(Paint.FILTER_BITMAP_FLAG))
            y += dh + 10f
        }
    }
}
