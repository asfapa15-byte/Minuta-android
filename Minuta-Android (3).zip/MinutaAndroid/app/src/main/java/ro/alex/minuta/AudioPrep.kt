package ro.alex.minuta

import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer

/** Gets audio into a format Gemini accepts. */
object AudioPrep {

    private val SAMPLE_RATES = listOf(96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350)

    fun forGemini(f: File): Pair<String, ByteArray> = when (f.extension.lowercase()) {
        "m4a", "mp4" -> "audio/aac" to toAdts(f)
        "aac" -> "audio/aac" to f.readBytes()
        "mp3", "mpeg", "mpga" -> "audio/mp3" to f.readBytes()
        "wav" -> "audio/wav" to f.readBytes()
        "ogg" -> "audio/ogg" to f.readBytes()
        "flac" -> "audio/flac" to f.readBytes()
        else -> throw ApiException("Format audio nesuportat de Gemini (.${f.extension}). Folosește m4a, mp3 sau wav.", false)
    }

    /**
     * Repackages the AAC audio of an .m4a file as a raw ADTS (.aac) stream,
     * without re-encoding: each AAC frame gets a 7-byte ADTS header.
     */
    private fun toAdts(f: File): ByteArray {
        val ex = MediaExtractor()
        try {
            ex.setDataSource(f.absolutePath)
            var format: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val tf = ex.getTrackFormat(i)
                if (tf.getString(MediaFormat.KEY_MIME) == MediaFormat.MIMETYPE_AUDIO_AAC) {
                    ex.selectTrack(i)
                    format = tf
                    break
                }
            }
            if (format == null) throw ApiException("Fișierul nu conține audio AAC.", false)

            val sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            val channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val objectType = if (format.containsKey(MediaFormat.KEY_AAC_PROFILE)) format.getInteger(MediaFormat.KEY_AAC_PROFILE) else 2
            val freqIdx = SAMPLE_RATES.indexOf(sampleRate).let { if (it < 0) 4 else it }
            val profile = (if (objectType in 1..4) objectType else 2) - 1

            val out = ByteArrayOutputStream((f.length() * 11 / 10).toInt().coerceAtLeast(1024))
            val buf = ByteBuffer.allocate(1 shl 16)
            val frame = ByteArray(1 shl 16)
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                buf.position(0)
                buf.limit(size)
                buf.get(frame, 0, size)
                val len = size + 7
                out.write(0xFF)
                out.write(0xF1)
                out.write((profile shl 6) or (freqIdx shl 2) or (channels shr 2))
                out.write(((channels and 3) shl 6) or (len shr 11))
                out.write((len and 0x7FF) shr 3)
                out.write(((len and 7) shl 5) or 0x1F)
                out.write(0xFC)
                out.write(frame, 0, size)
                ex.advance()
            }
            return out.toByteArray()
        } finally {
            ex.release()
        }
    }
}
