package ro.alex.minuta

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Check and correct the minute before it goes out. */
class EditMinuteActivity : LockedActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun intent(ctx: Context, id: String): Intent =
            Intent(ctx, EditMinuteActivity::class.java).putExtra(EXTRA_ID, id)
    }

    private class ActionRow(
        val id: String,
        val view: View,
        val task: TextInputEditText,
        val owner: TextInputEditText,
        val due: TextInputEditText,
        val dueDate: String,
        val done: Boolean,
    )

    private lateinit var id: String
    private lateinit var content: LinearLayout
    private lateinit var actionsBox: LinearLayout
    private lateinit var titleF: TextInputEditText
    private lateinit var summaryF: TextInputEditText
    private lateinit var decisionsF: TextInputEditText
    private var recipientsF: TextInputEditText? = null
    private val rows = mutableListOf<ActionRow>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        id = intent.getStringExtra(EXTRA_ID) ?: run { finish(); return }
        val m = MeetingRepo.get(this, id) ?: run { finish(); return }
        val l = m.labels()
        setContentView(R.layout.activity_minute)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        toolbar.title = "Verifică minuta"
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }
        content = findViewById(R.id.content)

        titleF = field("Titlu", m.title, multiline = false)
        summaryF = field(l.summary, m.summary, multiline = true)
        decisionsF = field("${l.decisions} (câte una pe rând)", m.decisions.joinToString("\n"), multiline = true)

        content.addView(label(l.actions))
        actionsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(actionsBox)
        for (a in m.actions) addRow(a.id, a.task, a.owner, a.due, a.dueDate, a.done, l)
        content.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "+ Adaugă acțiune"
            setOnClickListener { addRow(ActionItem.newId(), "", "", "", "", false, l) }
        })

        if (Mailer.ready(this)) {
            recipientsF = field("Trimite la (e-mailuri, separate prin virgulă)", m.emailTo, multiline = true, email = true)
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(24), 0, 0)
        }
        buttons.addView(MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "Salvează"
            setOnClickListener { if (save()) finish() }
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(8) })
        if (Mailer.ready(this)) {
            buttons.addView(MaterialButton(this).apply {
                text = "Salvează și trimite"
                setOnClickListener { saveAndSend(this) }
            }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(8) })
        }
        content.addView(buttons)
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun label(s: String) = TextView(this).apply {
        setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleMedium)
        text = s
        setPadding(0, dp(20), 0, dp(4))
    }

    private fun makeField(hint: String, value: String, multiline: Boolean, email: Boolean = false): Pair<TextInputLayout, TextInputEditText> {
        val layout = TextInputLayout(this, null, com.google.android.material.R.attr.textInputOutlinedStyle)
        layout.hint = hint
        val edit = TextInputEditText(layout.context)
        edit.inputType = when {
            email -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            multiline -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            else -> InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        }
        if (multiline) edit.minLines = 2
        edit.setText(value)
        layout.addView(edit)
        return layout to edit
    }

    private fun field(hint: String, value: String, multiline: Boolean, email: Boolean = false): TextInputEditText {
        val (layout, edit) = makeField(hint, value, multiline, email)
        content.addView(layout, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(12) })
        return edit
    }

    private fun addRow(actionId: String, task: String, owner: String, due: String, dueDate: String, done: Boolean, l: Labels) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val (tl, tf) = makeField(l.action, task, multiline = true)
        box.addView(tl)
        val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val (ol, of) = makeField(l.owner, owner, multiline = false)
        val (dl, df) = makeField(l.due, due, multiline = false)
        line.addView(ol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginEnd = dp(6) })
        line.addView(dl, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply { marginStart = dp(6) })
        box.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(6) })
        val row = ActionRow(actionId, box, tf, of, df, dueDate, done)
        box.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
            text = "Șterge acțiunea"
            setOnClickListener {
                actionsBox.removeView(box)
                rows.remove(row)
            }
        })
        rows.add(row)
        actionsBox.addView(box)
    }

    private fun save(): Boolean {
        val to = recipientsF?.text?.toString().orEmpty()
        val bad = Mailer.invalidAddresses(to)
        if (bad.isNotEmpty()) {
            recipientsF?.error = "Adresă greșită: ${bad.joinToString()}"
            return false
        }
        val m0 = MeetingRepo.get(this, id) ?: return false
        val tbd = m0.labels().tbd
        MeetingRepo.update(this, id) { m ->
            m.title = titleF.text?.toString().orEmpty().trim()
            m.summary = summaryF.text?.toString().orEmpty().trim()
            m.decisions.clear()
            m.decisions.addAll(decisionsF.text?.toString().orEmpty().lines().map { it.trim().removePrefix("•").removePrefix("-").trim() }
                .filter { it.isNotEmpty() })
            m.actions.clear()
            for (r in rows) {
                val task = r.task.text?.toString().orEmpty().trim()
                if (task.isEmpty()) continue
                val dueText = r.due.text?.toString().orEmpty().trim().ifEmpty { tbd }
                val original = m0.actions.firstOrNull { it.id == r.id }
                // If the due text was changed by hand, the computed date no longer applies.
                val dueDate = if (original != null && original.due == dueText) r.dueDate else ""
                m.actions.add(ActionItem(r.id, task, r.owner.text?.toString().orEmpty().trim().ifEmpty { tbd }, dueText, dueDate, r.done))
            }
            if (recipientsF != null) {
                m.emailTo = Mailer.parseAddresses(to).joinToString(", ")
                if (m.emailTo.isNotEmpty()) Prefs.save(this, mapOf("last_recipients" to m.emailTo))
            }
        }
        return true
    }

    private fun saveAndSend(button: MaterialButton) {
        if (!save()) return
        val m = MeetingRepo.get(this, id) ?: return
        if (m.emailTo.isBlank()) {
            recipientsF?.error = "Scrie cel puțin o adresă."
            return
        }
        button.isEnabled = false
        Toast.makeText(this, "Se trimite…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) { Mailer.sendMinute(applicationContext, id) }
            button.isEnabled = true
            if (err == null) {
                Toast.makeText(this@EditMinuteActivity, "Minuta a fost trimisă la ${m.emailTo}", Toast.LENGTH_LONG).show()
                finish()
            } else {
                Toast.makeText(this@EditMinuteActivity, err, Toast.LENGTH_LONG).show()
            }
        }
    }
}
