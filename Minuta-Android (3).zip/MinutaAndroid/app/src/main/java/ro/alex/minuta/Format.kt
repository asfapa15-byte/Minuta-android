package ro.alex.minuta

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Format {
    val RO: Locale = Locale.forLanguageTag("ro-RO")

    fun duration(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%02d:%02d", m, sec)
    }

    fun date(ms: Long): String = SimpleDateFormat("d MMMM yyyy, HH:mm", RO).format(Date(ms))

    fun date(ms: Long, lang: String): String =
        if (lang == "en") SimpleDateFormat("d MMMM yyyy, HH:mm", Locale.UK).format(Date(ms)) else date(ms)

    fun shortDate(ms: Long): String = SimpleDateFormat("dd.MM.yyyy", Locale.US).format(Date(ms))

    fun time(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

    fun longDate(ms: Long): String = SimpleDateFormat("EEEE, d MMMM yyyy, HH:mm", RO).format(Date(ms))

    /** "2026-11-28" -> "28.11.2026" (or the input if it doesn't parse). */
    fun isoToShort(iso: String): String = try {
        val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(iso)
        if (d == null) iso else SimpleDateFormat("dd.MM.yyyy", Locale.US).format(d)
    } catch (e: Exception) {
        iso
    }

    fun todayIsoOf(ms: Long): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date(ms))

    fun todayIso(offsetDays: Int = 0): String {
        val c = java.util.Calendar.getInstance()
        c.add(java.util.Calendar.DAY_OF_YEAR, offsetDays)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(c.time)
    }

    fun statusLabel(m: Meeting): String = when (m.status) {
        Status.RECORDING -> "Se înregistrează"
        Status.PENDING -> "În așteptare"
        Status.TRANSCRIBING -> "Se transcrie…"
        Status.SUMMARIZING -> "Se scrie minuta…"
        Status.ERROR -> "Eroare – deschide pentru a reîncerca"
        Status.DONE -> when (m.actions.size) {
            0 -> "Fără acțiuni"
            1 -> "1 acțiune"
            else -> "${m.actions.size} acțiuni"
        }
    }
}
