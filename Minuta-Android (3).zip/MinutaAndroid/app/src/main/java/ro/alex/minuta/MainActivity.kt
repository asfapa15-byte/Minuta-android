package ro.alex.minuta

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date

class MainActivity : LockedActivity() {

    private lateinit var banner: TextView
    private lateinit var empty: TextView
    private lateinit var list: RecyclerView
    private lateinit var fab: ExtendedFloatingActionButton
    private val adapter = MeetingAdapter { m -> startActivity(MinuteActivity.intent(this, m.id)) }
    private var query = ""
    private var pendingDelete: String? = null
    private var firstLoad = true

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) importAudio(uri)
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        refreshBanner()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        banner = findViewById(R.id.banner)
        empty = findViewById(R.id.empty)
        list = findViewById(R.id.list)
        fab = findViewById(R.id.fab)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ItemTouchHelper(SwipeToDelete()).attachToRecyclerView(list)

        // Shrink the button to an icon while scrolling down, grow it back when scrolling up.
        list.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(rv: RecyclerView, dx: Int, dy: Int) {
                if (dy > 6 && fab.isExtended) fab.shrink() else if (dy < -6 && !fab.isExtended) fab.extend()
            }
        })

        fab.setOnClickListener {
            Ui.confirm(it)
            startActivity(Intent(this, RecordActivity::class.java))
        }
        Ui.bottomNav(this, findViewById<BottomNavigationView>(R.id.bottom_nav), R.id.nav_meetings)

        // Ask once for notifications (minute ready, deadlines). Android 13+ needs explicit consent.
        if (savedInstanceState == null && android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.hasPermission(this) &&
            Prefs.raw(this, "asked_notifications") != "1"
        ) {
            Prefs.save(this, mapOf("asked_notifications" to "1"))
            notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { MeetingRepo.changes.collect { refresh() } }
                launch { RecordingService.state.collect { refreshBanner() } }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<BottomNavigationView>(R.id.bottom_nav).menu.findItem(R.id.nav_meetings)?.isChecked = true
        refreshBanner()
    }

    private fun refresh() {
        val recId = RecordingService.state.value.meetingId
        val items = MeetingRepo.all(this).filter { it.id != pendingDelete }
        // A recording interrupted by a crash or reboot: mark it so it can be processed.
        for (m in items) {
            if (m.status == Status.RECORDING && m.id != recId) {
                MeetingRepo.update(this, m.id) { it.status = Status.PENDING }
            }
        }
        val shown = if (query.isBlank()) items.map { it to "" } else Search.filter(items, query)
        adapter.submit(shown)
        if (firstLoad && shown.isNotEmpty()) {
            firstLoad = false
            list.scheduleLayoutAnimation()
        }
        empty.text = if (items.isEmpty()) getString(R.string.empty_list) else "Nimic găsit pentru „$query”."
        empty.visibility = if (shown.isEmpty()) View.VISIBLE else View.GONE
        refreshBanner()
    }

    private fun refreshBanner() {
        val rec = RecordingService.state.value.meetingId
        when {
            rec != null -> {
                banner.text = "●  Înregistrare în curs – atinge pentru a reveni"
                banner.setOnClickListener { startActivity(Intent(this, RecordActivity::class.java)) }
                banner.visibility = View.VISIBLE
            }
            !Notifier.enabled(this) -> {
                banner.text = "Notificările sunt oprite – nu afli când e gata minuta. Atinge ca să le pornești."
                banner.setOnClickListener {
                    if (android.os.Build.VERSION.SDK_INT >= 33 && !Notifier.hasPermission(this) &&
                        shouldShowRequestPermissionRationale(android.Manifest.permission.POST_NOTIFICATIONS)
                    ) notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                    else Notifier.openSettings(this)
                }
                banner.visibility = View.VISIBLE
            }
            !Prefs.hasKeys(this) -> {
                banner.text = "Adaugă cheia AI în Setări ca să poți genera minute. Atinge aici."
                banner.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
                banner.visibility = View.VISIBLE
            }
            else -> banner.visibility = View.GONE
        }
    }

    private fun importAudio(uri: Uri) {
        Toast.makeText(this, "Se importă fișierul…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { Importer.import(this@MainActivity, uri) } }
            result.onSuccess { id ->
                RecordingService.send(this@MainActivity, RecordingService.ACTION_PROCESS, id)
                startActivity(MinuteActivity.intent(this@MainActivity, id))
            }.onFailure { e ->
                Toast.makeText(this@MainActivity, e.message ?: "Importul a eșuat.", Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Swipe a card to the left to delete it, with a few seconds to undo. */
    private inner class SwipeToDelete : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
        private val red = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(this@MainActivity, R.color.accent) }
        private val icon = ContextCompat.getDrawable(this@MainActivity, R.drawable.ic_delete)?.mutate()?.apply {
            setTint(ContextCompat.getColor(this@MainActivity, R.color.on_accent))
        }
        private val rect = RectF()
        private var buzzed = false

        override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false

        override fun getSwipeDirs(rv: RecyclerView, vh: RecyclerView.ViewHolder): Int {
            val m = adapter.meetingAt(vh.bindingAdapterPosition) ?: return 0
            val busy = RecordingService.state.value.meetingId == m.id || Processor.isRunning(m.id)
            return if (busy) 0 else ItemTouchHelper.LEFT
        }

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {
            val pos = vh.bindingAdapterPosition
            val m = adapter.meetingAt(pos) ?: return
            Ui.heavy(vh.itemView)
            // Finish any earlier pending delete first.
            pendingDelete?.let { MeetingRepo.delete(this@MainActivity, it) }
            pendingDelete = m.id
            adapter.removeAt(pos)
            Snackbar.make(list, "„${m.displayTitle()}” a fost ștearsă", Snackbar.LENGTH_LONG)
                .setAnchorView(fab)
                .setAction("Anulează") {
                    pendingDelete = null
                    refresh()
                }
                .addCallback(object : Snackbar.Callback() {
                    override fun onDismissed(bar: Snackbar?, event: Int) {
                        if (event != DISMISS_EVENT_ACTION && pendingDelete == m.id) {
                            pendingDelete = null
                            MeetingRepo.delete(this@MainActivity, m.id)
                        }
                    }
                })
                .show()
        }

        override fun onChildDraw(
            c: Canvas, rv: RecyclerView, vh: RecyclerView.ViewHolder,
            dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean,
        ) {
            val v = vh.itemView
            val d = resources.displayMetrics.density
            if (dX < 0) {
                rect.set(v.right + dX, v.top + 4 * d, v.right - 4 * d, v.bottom - 4 * d)
                c.drawRoundRect(rect, 18 * d, 18 * d, red)
                icon?.let {
                    val size = (24 * d).toInt()
                    val top = v.top + (v.height - size) / 2
                    val right = v.right - (28 * d).toInt()
                    it.setBounds(right - size, top, right, top + size)
                    if (-dX > size * 2) it.draw(c)
                }
                val past = -dX > v.width * 0.5f
                if (past && !buzzed && isCurrentlyActive) Ui.tick(v)
                buzzed = past
            }
            super.onChildDraw(c, rv, vh, dX, dY, actionState, isCurrentlyActive)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        val search = menu.findItem(R.id.action_search)?.actionView as? androidx.appcompat.widget.SearchView
        search?.queryHint = "Caută în ședințe"
        search?.setOnQueryTextListener(object : androidx.appcompat.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(q: String?): Boolean {
                search?.clearFocus()
                return true
            }

            override fun onQueryTextChange(q: String?): Boolean {
                query = q.orEmpty()
                refresh()
                return true
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_import -> {
            pickAudio.launch(arrayOf("audio/*"))
            true
        }
        else -> super.onOptionsItemSelected(item)
    }
}

class MeetingAdapter(private val onClick: (Meeting) -> Unit) : RecyclerView.Adapter<MeetingAdapter.VH>() {
    private val items = mutableListOf<Pair<Meeting, String>>()
    private val dayFmt = SimpleDateFormat("d\nMMM", Format.RO)

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val day: TextView = v.findViewById(R.id.day)
        val title: TextView = v.findViewById(R.id.title)
        val subtitle: TextView = v.findViewById(R.id.subtitle)
        val status: TextView = v.findViewById(R.id.status)
        val snippet: TextView = v.findViewById(R.id.snippet)
    }

    fun meetingAt(pos: Int): Meeting? = items.getOrNull(pos)?.first

    fun removeAt(pos: Int) {
        if (pos !in items.indices) return
        items.removeAt(pos)
        notifyItemRemoved(pos)
    }

    @android.annotation.SuppressLint("NotifyDataSetChanged")
    fun submit(list: List<Pair<Meeting, String>>) {
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_meeting, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val (m, snippet) = items[position]
        val ctx = holder.itemView.context
        holder.day.text = dayFmt.format(Date(m.createdAt)).replace(".", "")
        holder.title.text = m.displayTitle()
        val parts = mutableListOf(Format.time(m.createdAt))
        if (m.durationMs > 0) parts.add(Format.duration(m.durationMs))
        if (m.participants.isNotBlank()) parts.add(m.participants)
        holder.subtitle.text = parts.joinToString(" · ")

        val open = m.actions.count { !it.done }
        val (label, fg, bg) = when (m.status) {
            Status.RECORDING -> Triple("● Se înregistrează", R.color.accent, R.color.accent_soft)
            Status.PENDING, Status.TRANSCRIBING, Status.SUMMARIZING ->
                Triple(Format.statusLabel(m), R.color.warning, R.color.warning_soft)
            Status.ERROR -> Triple("Eroare – atinge pentru a reîncerca", R.color.error, R.color.accent_soft)
            Status.DONE -> when {
                m.emailSentAt == 0L && m.emailTo.isNotBlank() && m.emailError == null ->
                    Triple("De verificat și trimis", R.color.secondary, R.color.secondary_soft)
                open > 0 -> Triple(if (open == 1) "1 acțiune deschisă" else "$open acțiuni deschise", R.color.secondary, R.color.secondary_soft)
                else -> Triple("✓ Gata", R.color.success, R.color.success_soft)
            }
        }
        holder.status.text = label
        holder.status.setTextColor(ContextCompat.getColor(ctx, fg))
        holder.status.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(ctx, bg))

        holder.snippet.text = snippet
        holder.snippet.visibility = if (snippet.isEmpty()) View.GONE else View.VISIBLE
        holder.itemView.setOnClickListener { onClick(m) }
    }
}
