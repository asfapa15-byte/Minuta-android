package ro.alex.minuta

import java.text.Normalizer
import java.util.Locale

/** Finds meetings by any word: title, people, summary, decisions, actions or transcript. Ignores diacritics. */
object Search {

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    /** Returns the matching meetings, each with a short excerpt around the match. */
    fun filter(items: List<Meeting>, query: String): List<Pair<Meeting, String>> {
        val words = norm(query).split(' ').map { it.trim() }.filter { it.isNotEmpty() }
        if (words.isEmpty()) return items.map { it to "" }
        val out = mutableListOf<Pair<Meeting, String>>()
        for (m in items) {
            val fields = listOf(
                m.title, m.participants, m.summary,
                m.decisions.joinToString(" · "),
                m.actions.joinToString(" · ") { "${it.task} (${it.owner})" },
                m.transcript,
            )
            val all = norm(fields.joinToString("\n"))
            if (words.all { all.contains(it) }) {
                out.add(m to excerpt(fields, words.first()))
            }
        }
        return out
    }

    private fun excerpt(fields: List<String>, word: String): String {
        // Title and people already show in the list; prefer the content.
        for (f in fields.drop(2)) {
            val n = norm(f)
            val i = n.indexOf(word)
            if (i >= 0) {
                val start = (i - 50).coerceAtLeast(0)
                val end = (i + word.length + 70).coerceAtMost(f.length)
                return (if (start > 0) "…" else "") + f.substring(start, end).replace('\n', ' ').trim() + (if (end < f.length) "…" else "")
            }
        }
        return ""
    }
}
