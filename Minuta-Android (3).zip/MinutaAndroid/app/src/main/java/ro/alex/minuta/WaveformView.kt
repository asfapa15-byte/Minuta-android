package ro.alex.minuta

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** Live sound bars: new levels enter on the right and scroll left. */
class WaveformView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null,
) : View(context, attrs) {

    private val levels = FloatArray(64)
    private var head = 0
    private var active = false
    private val rect = RectF()
    private val on = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(context, R.color.accent) }
    private val off = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(context, R.color.divider) }

    /** [amplitude] is MediaRecorder.getMaxAmplitude(): 0..32767. */
    fun push(amplitude: Int) {
        // Square root makes quiet speech still visible.
        val v = min(1f, sqrt(amplitude / 32767f) * 1.6f)
        levels[head] = v
        head = (head + 1) % levels.size
        invalidate()
    }

    fun setActive(value: Boolean) {
        if (active == value) return
        active = value
        if (!value) levels.fill(0f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val n = levels.size
        val gap = width / (n * 3f)
        val barW = (width - gap * (n - 1)) / n
        val mid = height / 2f
        for (i in 0 until n) {
            val v = levels[(head + i) % n]
            val h = max(barW, v * height * 0.92f)
            val x = i * (barW + gap)
            rect.set(x, mid - h / 2, x + barW, mid + h / 2)
            canvas.drawRoundRect(rect, barW / 2, barW / 2, if (active && v > 0.02f) on else off)
        }
    }
}
