package ro.alex.minuta

import org.json.JSONArray
import org.json.JSONObject

/**
 * One action from a minute. [dueDate] is "yyyy-MM-dd" when the AI could work out a date, else "".
 * [id] stays the same across edits, so "done" ticks survive.
 */
data class ActionItem(
    val id: String,
    val task: String,
    val owner: String,
    val due: String,
    val dueDate: String = "",
    var done: Boolean = false,
) {
    companion object {
        private var counter = 0
        fun newId(): String = System.currentTimeMillis().toString(36) + "-" + (counter++).toString(36)
    }
}

enum class Status { RECORDING, PENDING, TRANSCRIBING, SUMMARIZING, DONE, ERROR }

class Meeting(
    val id: String,
    var title: String,
    var participants: String,
    val createdAt: Long,
) {
    var durationMs: Long = 0
    var status: Status = Status.RECORDING
    var error: String? = null

    /** Spoken language: "ro", "en" or "auto". Minute language: "ro" or "en". */
    var spokenLang: String = "ro"
    var minuteLang: String = "ro"

    /** Audio file names inside the meeting folder, in order. */
    val segments: MutableList<String> = mutableListOf()

    /** Transcript per audio file, so a retry does not pay twice. */
    val segmentTranscripts: MutableMap<String, String> = mutableMapOf()

    /** Photos of the whiteboard / slides (file names in the meeting folder). */
    val photos: MutableList<String> = mutableListOf()

    /** Name -> e-mail of people in this meeting (from the calendar). */
    val contacts: MutableMap<String, String> = mutableMapOf()

    var transcript: String = ""
    var summary: String = ""
    val decisions: MutableList<String> = mutableListOf()
    val actions: MutableList<ActionItem> = mutableListOf()

    /** E-mail recipients chosen for this meeting (comma separated). */
    var emailTo: String = ""
    var emailSentAt: Long = 0
    var emailError: String? = null
    var tasksSentAt: Long = 0

    fun labels(): Labels = Labels.of(minuteLang)

    fun displayTitle(): String = title.ifBlank { labels().untitled }

    fun toJson(): JSONObject {
        val o = JSONObject()
        o.put("id", id)
        o.put("title", title)
        o.put("participants", participants)
        o.put("createdAt", createdAt)
        o.put("durationMs", durationMs)
        o.put("status", status.name)
        o.put("error", error ?: JSONObject.NULL)
        o.put("spokenLang", spokenLang)
        o.put("minuteLang", minuteLang)
        o.put("segments", JSONArray(segments))
        val st = JSONObject()
        for ((k, v) in segmentTranscripts) st.put(k, v)
        o.put("segmentTranscripts", st)
        o.put("photos", JSONArray(photos))
        val ct = JSONObject()
        for ((k, v) in contacts) ct.put(k, v)
        o.put("contacts", ct)
        o.put("transcript", transcript)
        o.put("summary", summary)
        o.put("decisions", JSONArray(decisions))
        val acts = JSONArray()
        for (a in actions) {
            acts.put(
                JSONObject().put("id", a.id).put("task", a.task).put("owner", a.owner)
                    .put("due", a.due).put("dueDate", a.dueDate).put("done", a.done)
            )
        }
        o.put("actions", acts)
        o.put("emailTo", emailTo)
        o.put("emailSentAt", emailSentAt)
        o.put("emailError", emailError ?: JSONObject.NULL)
        o.put("tasksSentAt", tasksSentAt)
        return o
    }

    /** Plain-text minute, for sharing, copying and the text part of the e-mail. */
    fun toShareText(): String {
        val l = labels()
        val sb = StringBuilder()
        sb.append(l.minute.uppercase()).append(": ").append(displayTitle()).append('\n')
        sb.append(l.date).append(": ").append(Format.date(createdAt, minuteLang)).append('\n')
        if (durationMs > 0) sb.append(l.duration).append(": ").append(Format.duration(durationMs)).append('\n')
        if (participants.isNotBlank()) sb.append(l.participants).append(": ").append(participants).append('\n')
        sb.append('\n').append(l.summary.uppercase()).append('\n').append(summary.ifBlank { "-" }).append('\n')
        sb.append('\n').append(l.decisions.uppercase()).append('\n')
        if (decisions.isEmpty()) sb.append("- ").append(l.noDecisions).append('\n')
        for (d in decisions) sb.append("- ").append(d).append('\n')
        sb.append('\n').append(l.actions.uppercase()).append('\n')
        if (actions.isEmpty()) sb.append("- ").append(l.noActions).append('\n')
        for (a in actions) {
            sb.append("- ").append(a.task)
                .append(" | ").append(l.owner).append(": ").append(a.owner)
                .append(" | ").append(l.due).append(": ").append(a.due).append('\n')
        }
        sb.append('\n').append(l.transcript.uppercase()).append('\n').append(transcript.ifBlank { "-" }).append('\n')
        return sb.toString()
    }

    companion object {
        fun fromJson(o: JSONObject): Meeting {
            val m = Meeting(
                o.getString("id"),
                o.optString("title", ""),
                o.optString("participants", ""),
                o.optLong("createdAt", 0L),
            )
            m.durationMs = o.optLong("durationMs", 0L)
            m.status = runCatching { Status.valueOf(o.optString("status")) }.getOrDefault(Status.PENDING)
            m.error = if (o.isNull("error")) null else o.optString("error")
            m.spokenLang = o.optString("spokenLang", "ro").ifEmpty { "ro" }
            m.minuteLang = o.optString("minuteLang", "ro").ifEmpty { "ro" }
            o.optJSONArray("segments")?.let { a ->
                for (i in 0 until a.length()) m.segments.add(a.getString(i))
            }
            o.optJSONObject("segmentTranscripts")?.let { t ->
                val keys = t.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    m.segmentTranscripts[k] = t.optString(k, "")
                }
            }
            o.optJSONArray("photos")?.let { a ->
                for (i in 0 until a.length()) m.photos.add(a.getString(i))
            }
            o.optJSONObject("contacts")?.let { t ->
                val keys = t.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    m.contacts[k] = t.optString(k, "")
                }
            }
            m.transcript = o.optString("transcript", "")
            m.summary = o.optString("summary", "")
            o.optJSONArray("decisions")?.let { a ->
                for (i in 0 until a.length()) m.decisions.add(a.optString(i))
            }
            o.optJSONArray("actions")?.let { a ->
                for (i in 0 until a.length()) {
                    val x = a.optJSONObject(i) ?: continue
                    m.actions.add(
                        ActionItem(
                            x.optString("id", "").ifEmpty { m.id + "-" + i },
                            x.optString("task"),
                            x.optString("owner"),
                            x.optString("due"),
                            x.optString("dueDate", ""),
                            x.optBoolean("done", false),
                        )
                    )
                }
            }
            m.emailTo = o.optString("emailTo", "")
            m.emailSentAt = o.optLong("emailSentAt", 0L)
            m.emailError = if (o.isNull("emailError")) null else o.optString("emailError")
            m.tasksSentAt = o.optLong("tasksSentAt", 0L)
            return m
        }
    }
}
