package ro.alex.minuta

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import java.util.concurrent.TimeUnit

/**
 * When the AI is overloaded or the internet drops, the meeting is processed again
 * by itself: after 10, 20, then 40 minutes, and only when there is a connection.
 */
class RetryWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val id = inputData.getString(KEY_ID) ?: return Result.success()
        val m = MeetingRepo.get(applicationContext, id) ?: return Result.success()
        if (m.status != Status.ERROR || Processor.isRunning(id)) return Result.success()
        Processor.processNow(applicationContext, id)
        val after = MeetingRepo.get(applicationContext, id)
        if (after?.status == Status.DONE) {
            Prefs.save(applicationContext, mapOf("retries_$id" to ""))
            RecordingService.notifyFinished(applicationContext, id)
        }
        return Result.success()
    }

    companion object {
        private const val KEY_ID = "id"
        private const val MAX = 3

        /** Schedules the next automatic try. Returns its time ("HH:mm"), or null after 3 tries. */
        fun schedule(ctx: Context, id: String): String? {
            val tries = Prefs.raw(ctx, "retries_$id").toIntOrNull() ?: 0
            if (tries >= MAX) return null
            Prefs.save(ctx, mapOf("retries_$id" to (tries + 1).toString()))
            val minutes = 10L shl tries // 10, 20, 40
            val request = OneTimeWorkRequestBuilder<RetryWorker>()
                .setInitialDelay(minutes, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInputData(workDataOf(KEY_ID to id))
                .build()
            return try {
                WorkManager.getInstance(ctx).enqueueUniqueWork("retry_$id", ExistingWorkPolicy.REPLACE, request)
                Format.time(System.currentTimeMillis() + minutes * 60_000)
            } catch (e: Exception) {
                null
            }
        }
    }
}
