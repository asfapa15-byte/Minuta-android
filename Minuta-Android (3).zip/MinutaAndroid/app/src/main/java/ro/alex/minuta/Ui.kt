package ro.alex.minuta

import android.app.Activity
import android.content.Intent
import android.os.Build
import android.view.HapticFeedbackConstants
import android.view.View
import com.google.android.material.bottomnavigation.BottomNavigationView

/** Small shared bits of the new design: bottom tabs and vibration feedback. */
object Ui {

    /** Wires the bottom tabs (Ședințe · Acțiuni · Setări). Each tab is its own screen. */
    fun bottomNav(activity: Activity, nav: BottomNavigationView, selected: Int) {
        nav.selectedItemId = selected
        nav.setOnItemSelectedListener { item ->
            if (item.itemId == selected) return@setOnItemSelectedListener true
            val target = when (item.itemId) {
                R.id.nav_actions -> ActionsActivity::class.java
                R.id.nav_settings -> SettingsActivity::class.java
                else -> MainActivity::class.java
            }
            tick(nav)
            activity.startActivity(Intent(activity, target).addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT))
            @Suppress("DEPRECATION")
            activity.overridePendingTransition(R.anim.fade_in_short, R.anim.fade_out_short)
            true
        }
        nav.setOnItemReselectedListener { }
    }

    /** Light tap, for toggles and tabs. */
    fun tick(v: View) {
        v.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
    }

    /** Firm confirmation, for start / stop / done. */
    fun confirm(v: View) {
        v.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.CONFIRM else HapticFeedbackConstants.LONG_PRESS
        )
    }

    /** Swipe threshold crossed, delete, etc. */
    fun heavy(v: View) {
        v.performHapticFeedback(
            if (Build.VERSION.SDK_INT >= 30) HapticFeedbackConstants.REJECT else HapticFeedbackConstants.LONG_PRESS
        )
    }
}
