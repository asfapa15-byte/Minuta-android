package ro.alex.minuta

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

/** Notification channels, permission state and a test notification. */
object Notifier {

    fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel("recording", "Înregistrare", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel("done", "Minute gata", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel("reminders", "Termene acțiuni", NotificationManager.IMPORTANCE_DEFAULT))
    }

    fun hasPermission(ctx: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    /** Permission given and the app's notifications switched on. */
    fun enabled(ctx: Context): Boolean = hasPermission(ctx) && NotificationManagerCompat.from(ctx).areNotificationsEnabled()

    /** Opens the phone's notification settings for Minuta. */
    fun openSettings(ctx: Context) {
        val intent = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            ctx.startActivity(intent)
        } catch (e: Exception) {
            ctx.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:" + ctx.packageName))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }

    /** Returns false if notifications are off (nothing was shown). */
    fun sendTest(ctx: Context): Boolean {
        ensureChannels(ctx)
        if (!enabled(ctx)) return false
        val pi = PendingIntent.getActivity(
            ctx, 31, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, "done")
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Notificările funcționează")
            .setContentText("Așa vei afla când minuta e gata și când se apropie un termen.")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        return try {
            NotificationManagerCompat.from(ctx).notify(99, n)
            true
        } catch (e: SecurityException) {
            false
        }
    }
}
