package ro.alex.minuta

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

/** Turns a meeting's audio (and photos) into a transcript, then into a minute, then e-mails it. */
object Processor {
    private val running = mutableSetOf<String>()

    fun isRunning(id: String): Boolean = synchronized(running) { id in running }

    suspend fun process(ctx: Context, id: String) {
        withContext(Dispatchers.IO) { processBlocking(ctx, id) }
    }

    private fun processBlocking(ctx: Context, id: String) {
        val first = synchronized(running) { running.add(id) }
        if (first) {
            try {
                run(ctx, id)
            } catch (e: Exception) {
                val msg = when (e) {
                    is ApiException -> e.message
                    is IOException -> "Problemă de conexiune: ${e.message ?: "fără internet?"}"
                    else -> e.message ?: e.javaClass.simpleName
                }
                // Temporary problems (AI busy, no internet): try again by itself later.
                val temporary = (e is ApiException && e.retryable) || (e is IOException && e !is MailException)
                val next = if (temporary) RetryWorker.schedule(ctx, id) else null
                MeetingRepo.update(ctx, id) {
                    it.status = Status.ERROR
                    it.error = if (next != null) "$msg\n\nReîncerc automat la ora $next. Poți apăsa și acum Reîncearcă." else msg
                }
            } finally {
                synchronized(running) { running.remove(id) }
            }
        }
    }

    /** For the background retry: runs on the caller's thread. */
    fun processNow(ctx: Context, id: String) = processBlocking(ctx, id)

    private fun run(ctx: Context, id: String) {
        val provider = Prefs.provider(ctx)
        if (!Prefs.hasKeys(ctx)) {
            MeetingRepo.update(ctx, id) {
                it.status = Status.ERROR
                it.error = when (provider) {
                    Prefs.PROVIDER_GEMINI -> "Lipsește cheia Gemini. Completează-o în Setări, apoi apasă Reîncearcă."
                    Prefs.PROVIDER_GROQ -> "Lipsește cheia Groq. Completează-o în Setări, apoi apasă Reîncearcă."
                    else -> "Lipsesc cheile API. Completează-le în Setări, apoi apasă Reîncearcă."
                }
            }
            return
        }

        // 1. Transcribe every audio part not transcribed yet.
        val start = MeetingRepo.update(ctx, id) { it.status = Status.TRANSCRIBING; it.error = null } ?: return
        val dir = MeetingRepo.dir(ctx, id)
        val whisperLang = when (start.spokenLang) {
            "en" -> "en"
            "auto" -> null
            else -> "ro"
        }
        var previous = ""
        for (seg in start.segments) {
            val done = start.segmentTranscripts[seg]
            if (done != null) {
                previous = done
                continue
            }
            val f = File(dir, seg)
            val prompt = sttPrompt(start, previous)
            val text = if (!f.exists() || f.length() < 2_000) "" else Api.withRetry {
                when (provider) {
                    Prefs.PROVIDER_GEMINI -> cleanGemini(
                        Api.geminiTranscribe(Prefs.geminiKey(ctx), Prefs.geminiModel(ctx), f, geminiSttPrompt(start, previous))
                    )
                    Prefs.PROVIDER_GROQ -> Api.transcribe(
                        Api.GROQ_STT_URL, "Groq", f, Prefs.groqKey(ctx), Prefs.groqSttModel(ctx), prompt, whisperLang
                    )
                    else -> Api.transcribe(
                        Api.OPENAI_STT_URL, "OpenAI", f, Prefs.openAiKey(ctx), Prefs.sttModel(ctx), prompt, whisperLang
                    )
                }
            }
            MeetingRepo.update(ctx, id) { it.segmentTranscripts[seg] = text }
            if (text.isNotBlank()) previous = text
        }

        val m = MeetingRepo.update(ctx, id) { mm ->
            mm.transcript = mm.segments.mapNotNull { mm.segmentTranscripts[it] }
                .filter { it.isNotBlank() }.joinToString("\n\n")
            mm.status = Status.SUMMARIZING
        } ?: return
        if (m.transcript.isBlank() && m.photos.isEmpty()) {
            MeetingRepo.update(ctx, id) {
                it.status = Status.ERROR
                it.error = "Nu s-a detectat vorbire în înregistrare."
            }
            return
        }

        // 2. Write the minute (photos of the whiteboard/slides go along where the model can see them).
        val images: List<ByteArray> = if (provider == Prefs.PROVIDER_GROQ) emptyList()
        else m.photos.mapNotNull { ImageUtil.jpegForAi(File(dir, it)) }
        val answer = when (provider) {
            Prefs.PROVIDER_GEMINI -> Api.withRetry {
                Api.geminiText(
                    Prefs.geminiKey(ctx), Prefs.geminiModel(ctx), systemPrompt(ctx, m),
                    userPrompt(m, "TRANSCRIERE", m.transcript, images.isNotEmpty()), true, images
                )
            }
            Prefs.PROVIDER_GROQ -> freeMinute(ctx, m)
            else -> Api.withRetry {
                Api.claude(
                    Prefs.anthropicKey(ctx), Prefs.claudeModel(ctx), systemPrompt(ctx, m),
                    userPrompt(m, "TRANSCRIERE", m.transcript, images.isNotEmpty()), 4000, images
                )
            }
        }
        val json = parseJson(answer)
        val tbd = m.labels().tbd
        MeetingRepo.update(ctx, id) { mm ->
            if (mm.title.isBlank()) mm.title = json.optString("title", "").trim()
            mm.summary = json.optString("summary", "").trim()
            mm.decisions.clear()
            json.optJSONArray("decisions")?.let { a ->
                for (i in 0 until a.length()) a.optString(i).trim().takeIf { it.isNotEmpty() }?.let { mm.decisions.add(it) }
            }
            // Keep ticks of actions that survive a regeneration.
            val doneBefore = mm.actions.filter { it.done }.map { it.task.lowercase() }.toSet()
            mm.actions.clear()
            json.optJSONArray("actions")?.let { a ->
                for (i in 0 until a.length()) {
                    val x = a.optJSONObject(i) ?: continue
                    val task = x.optString("task").trim()
                    if (task.isEmpty()) continue
                    val dueDate = x.optString("due_date").trim().takeIf { Regex("\\d{4}-\\d{2}-\\d{2}").matches(it) } ?: ""
                    mm.actions.add(
                        ActionItem(
                            ActionItem.newId(),
                            task,
                            x.optString("owner").trim().ifEmpty { tbd },
                            x.optString("due").trim().ifEmpty { if (dueDate.isNotEmpty()) Format.isoToShort(dueDate) else tbd },
                            dueDate,
                            task.lowercase() in doneBefore,
                        )
                    )
                }
            }
            mm.status = Status.DONE
            mm.error = null
        }

        // 3. E-mail it automatically, once, unless you want to check it first.
        val done = MeetingRepo.get(ctx, id) ?: return
        if (!Prefs.reviewBeforeSend(ctx) && done.emailSentAt == 0L && done.emailTo.isNotBlank() && Mailer.ready(ctx)) {
            Mailer.sendMinute(ctx, id)
        }
    }

    /** Free plan allows ~8K tokens per minute, so long meetings are summarised part by part. */
    private const val CHUNK_CHARS = 9_000
    private const val FREE_PAUSE_MS = 45_000L

    private fun freeChat(ctx: Context, m: Meeting, user: String): String = Api.withRetry {
        Api.chat(Api.GROQ_CHAT_URL, "Groq", Prefs.groqKey(ctx), Prefs.groqChatModel(ctx), systemPrompt(ctx, m), user)
    }

    private fun freeMinute(ctx: Context, m: Meeting): String {
        if (m.transcript.length <= CHUNK_CHARS) {
            return freeChat(ctx, m, userPrompt(m, "TRANSCRIERE", m.transcript, false))
        }
        val chunks = splitText(m.transcript, CHUNK_CHARS)
        val notes = StringBuilder()
        chunks.forEachIndexed { i, chunk ->
            if (i > 0) Thread.sleep(FREE_PAUSE_MS)
            val part = freeChat(ctx, m, notesPrompt(m, i + 1, chunks.size, chunk))
            notes.append("PARTEA ").append(i + 1).append(":\n").append(part.trim()).append("\n\n")
        }
        Thread.sleep(FREE_PAUSE_MS)
        return freeChat(ctx, m, userPrompt(m, "NOTIȚE DIN FIECARE PARTE A ȘEDINȚEI (în ordine)", notes.toString(), false))
    }

    private fun splitText(text: String, max: Int): List<String> {
        val out = mutableListOf<String>()
        var rest = text
        while (rest.length > max) {
            var cut = rest.lastIndexOf(". ", max)
            if (cut < max / 2) cut = rest.lastIndexOf(' ', max)
            if (cut < max / 2) cut = max
            out.add(rest.substring(0, cut + 1).trim())
            rest = rest.substring(cut + 1)
        }
        if (rest.isNotBlank()) out.add(rest.trim())
        return out
    }

    private fun notesPrompt(m: Meeting, n: Int, total: Int, chunk: String): String = buildString {
        append("Data ședinței: ").append(Format.longDate(m.createdAt)).append('\n')
        append("Participanți declarați: ").append(m.participants.ifBlank { "(nespecificați)" }).append("\n\n")
        append("Mai jos este partea $n din $total a transcrierii automate a unei ședințe (poate avea greșeli de recunoaștere vocală). ")
        append("Extrage notițe concise. Răspunde DOAR cu JSON, fără alt text, cu forma: ")
        append("{\"points\": [\"subiect discutat\"], \"decisions\": [\"decizie\"], \"actions\": [{\"task\": \"ce\", \"owner\": \"cine\", \"due\": \"termen\"}]}")
        append("\n\nTRANSCRIERE (partea $n):\n").append(chunk)
    }

    private fun geminiSttPrompt(m: Meeting, previous: String): String = buildString {
        val lang = when (m.spokenLang) {
            "en" -> "în limba engleză (scrie textul în engleză)"
            "auto" -> "în limba vorbită (română, engleză sau amestec; păstrează fiecare frază în limba în care a fost rostită)"
            else -> "în limba română"
        }
        append("Transcrie fidel, cuvânt cu cuvânt, $lang, vorbirea din acest fragment audio al unei ședințe de lucru. ")
        append("Scrie doar textul rostit, cu punctuație corectă, împărțit în paragrafe. ")
        append("Nu traduce, nu rezuma, nu adăuga comentarii, titluri sau marcaje de timp. ")
        append("Dacă în fragment nu se vorbește deloc, răspunde exact cu: [LINISTE]")
        if (m.participants.isNotBlank()) append("\nParticipanți (pentru scrierea corectă a numelor): ").append(m.participants)
        if (m.title.isNotBlank()) append("\nSubiectul ședinței: ").append(m.title)
        if (previous.isNotBlank()) append("\nFinalul fragmentului anterior, pentru context: ").append(previous.takeLast(200))
    }

    private fun cleanGemini(text: String): String {
        val t = text.trim().removePrefix("```").removeSuffix("```").trim()
        return if (t.contains("[LINISTE]") && t.length < 40) "" else t
    }

    private fun sttPrompt(m: Meeting, previous: String): String {
        val sb = StringBuilder(if (m.spokenLang == "en") "Work meeting in English." else "Ședință de lucru.")
        if (m.title.isNotBlank()) sb.append(' ').append(m.title).append('.')
        if (m.participants.isNotBlank()) sb.append(' ').append(m.participants).append('.')
        if (previous.isNotBlank()) sb.append(' ').append(previous.takeLast(200))
        return sb.toString()
    }

    private fun systemPrompt(ctx: Context, m: Meeting): String {
        val extra = Prefs.context(ctx)
        return buildString {
            if (m.minuteLang == "en") {
                append("You are a careful, concise meeting secretary. You write meeting minutes in clear, professional English, ")
                append("factual, never inventing anything that was not discussed. The transcript may be in Romanian, English or both: ")
                append("write the minutes in English regardless.")
            } else {
                append("Ești un secretar de ședință atent și concis. Redactezi minute de ședință în limba română, ")
                append("clare, profesioniste, factuale, fără să inventezi nimic ce nu reiese din discuție. ")
                append("Transcrierea poate fi în română, engleză sau amestecat: minuta o scrii în română.")
            }
            if (extra.isNotEmpty()) append("\nContext: ").append(extra)
        }
    }

    private fun userPrompt(m: Meeting, label: String, material: String, hasImages: Boolean): String = buildString {
        val en = m.minuteLang == "en"
        val tbd = m.labels().tbd
        append("Data ședinței / meeting date: ").append(Format.longDate(m.createdAt))
            .append(" (").append(Format.todayIsoOf(m.createdAt)).append(")\n")
        append("Subiect declarat: ").append(m.title.ifBlank { "(nespecificat – propune unul scurt)" }).append('\n')
        append("Participanți declarați: ").append(m.participants.ifBlank { "(nespecificați)" }).append("\n\n")
        if (hasImages) {
            append("Imaginile atașate sunt fotografii ale tablei sau ale slide-urilor din ședință. ")
            append("Include în minută informațiile relevante din ele (cifre, diagrame, liste).\n\n")
        }
        append(
            """
            Mai jos este materialul ședinței (transcriere automată sau notițe extrase din ea). Poate conține greșeli de recunoaștere vocală și nu indică cine vorbește.
            Scrie minuta și răspunde DOAR cu un obiect JSON valid, fără alt text și fără ```, exact cu forma:
            {"title": "subiect scurt", "summary": "rezumat în 3-6 propoziții", "decisions": ["decizie"], "actions": [{"task": "ce trebuie făcut", "owner": "responsabil", "due": "termen, ca text", "due_date": "YYYY-MM-DD sau gol"}]}
            Reguli:
            - Include doar decizii și acțiuni care reies clar din discuție; dacă nu există, folosește liste goale.
            - Dacă responsabilul sau termenul nu reies clar, scrie "$tbd".
            - Pentru termene relative („vineri”, „săptămâna viitoare”) calculează data concretă pornind de la data ședinței: scrie-o în "due" ca text (de ex. „vineri, 28 noiembrie”) și în "due_date" ca YYYY-MM-DD. Dacă nu există termen, "due_date" este "".
            - Pentru "owner" folosește numele așa cum apar la participanți, când se potrivesc.
            - Corectează numele și termenii tehnici evident greșit transcriși.
            """.trimIndent()
        )
        append(if (en) "\n- Write title, summary, decisions, actions and due texts in ENGLISH." else "\n- Scrie totul în limba ROMÂNĂ.")
        append("\n\n").append(label).append(":\n").append(material.ifBlank { "(fără vorbire înregistrată)" })
    }

    private fun parseJson(text: String): JSONObject {
        val s = text.indexOf('{')
        val e = text.lastIndexOf('}')
        if (s < 0 || e <= s) throw IOException("Răspuns neașteptat de la modelul AI. Apasă Reîncearcă.")
        return try {
            JSONObject(text.substring(s, e + 1))
        } catch (ex: Exception) {
            throw IOException("Răspuns neașteptat de la modelul AI. Apasă Reîncearcă.")
        }
    }
}
