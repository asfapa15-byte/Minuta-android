package ro.alex.minuta

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

/**
 * Runs every morning (around 8:00):
 *  - reminds you of actions due today or tomorrow;
 *  - on the first working day of the week, e-mails you the summary of open actions.
 */
class DailyWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val ctx = applicationContext
        try {
            remindDue(ctx)
        } catch (e: Exception) {
            // Never let a reminder problem stop the digest.
        }
        try {
            maybeDigest(ctx)
        } catch (e: Exception) {
            // Tried again tomorrow.
        }
        MinutaWidget.refresh(ctx)
        return Result.success()
    }

    private fun remindDue(ctx: Context) {
        val today = Format.todayIso()
        val tomorrow = Format.todayIso(1)
        val due = MeetingRepo.all(ctx).flatMap { m -> m.actions.filter { !it.done && it.dueDate.isNotEmpty() }.map { m to it } }
        val todayList = due.filter { it.second.dueDate == today }
        val tomorrowList = due.filter { it.second.dueDate == tomorrow }
        val late = due.filter { it.second.dueDate < today }
        if (todayList.isEmpty() && tomorrowList.isEmpty() && late.isEmpty()) return
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return

        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Termene acțiuni", NotificationManager.IMPORTANCE_DEFAULT))

        val lines = mutableListOf<String>()
        for ((_, a) in late) lines.add("Întârziat: ${a.task} (${a.owner})")
        for ((_, a) in todayList) lines.add("Azi: ${a.task} (${a.owner})")
        for ((_, a) in tomorrowList) lines.add("Mâine: ${a.task} (${a.owner})")
        val title = buildList {
            if (todayList.isNotEmpty()) add("${todayList.size} azi")
            if (tomorrowList.isNotEmpty()) add("${tomorrowList.size} mâine")
            if (late.isNotEmpty()) add("${late.size} întârziate")
        }.joinToString(", ")

        val style = NotificationCompat.InboxStyle()
        lines.take(6).forEach { style.addLine(it) }
        if (lines.size > 6) style.setSummaryText("+${lines.size - 6} altele")
        val pi = PendingIntent.getActivity(
            ctx, 7, Intent(ctx, ActionsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(R.drawable.ic_mic)
            .setContentTitle("Termene acțiuni: $title")
            .setContentText(lines.first())
            .setStyle(style)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(42, n)
        } catch (e: SecurityException) {
            // Notifications not allowed.
        }
    }

    private fun maybeDigest(ctx: Context) {
        if (!Prefs.weeklyDigest(ctx) || !Mailer.ready(ctx)) return
        val c = Calendar.getInstance()
        val dow = c.get(Calendar.DAY_OF_WEEK)
        if (dow == Calendar.SATURDAY || dow == Calendar.SUNDAY) return
        val week = "${c.get(Calendar.YEAR)}-${c.get(Calendar.WEEK_OF_YEAR)}"
        if (Prefs.raw(ctx, "digest_week") == week) return
        if (Mailer.sendDigest(ctx) == null) Prefs.save(ctx, mapOf("digest_week" to week))
    }

    companion object {
        private const val CHANNEL = "reminders"

        fun schedule(ctx: Context) {
            val now = Calendar.getInstance()
            val next = (now.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 8)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                if (!after(now)) add(Calendar.DAY_OF_YEAR, 1)
            }
            val request = PeriodicWorkRequestBuilder<DailyWorker>(1, TimeUnit.DAYS)
                .setInitialDelay(next.timeInMillis - now.timeInMillis, TimeUnit.MILLISECONDS)
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("daily", ExistingPeriodicWorkPolicy.KEEP, request)
        }
    }
}
