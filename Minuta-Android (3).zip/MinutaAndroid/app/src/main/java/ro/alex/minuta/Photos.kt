package ro.alex.minuta

import android.content.Context
import android.net.Uri
import androidx.core.content.FileProvider
import java.io.File

/** Photos of the whiteboard / slides, stored next to the meeting's audio. */
object Photos {
    fun authority(ctx: Context) = ctx.packageName + ".files"

    fun newFile(ctx: Context, meetingId: String): File =
        File(MeetingRepo.dir(ctx, meetingId), "photo_${System.currentTimeMillis()}.jpg")

    fun uriFor(ctx: Context, f: File): Uri = FileProvider.getUriForFile(ctx, authority(ctx), f)

    /** Call after the camera returns: keeps the photo if one was taken. */
    fun keep(ctx: Context, meetingId: String, f: File, taken: Boolean): Boolean {
        if (taken && f.exists() && f.length() > 0) {
            MeetingRepo.update(ctx, meetingId) { it.photos.add(f.name) }
            return true
        }
        f.delete()
        return false
    }

    /** Copies a picture chosen from the gallery into the meeting. */
    fun import(ctx: Context, meetingId: String, uri: Uri): Boolean {
        val f = newFile(ctx, meetingId)
        val ok = try {
            ctx.contentResolver.openInputStream(uri)?.use { inp -> f.outputStream().use { inp.copyTo(it) } } != null
        } catch (e: Exception) {
            false
        }
        return keep(ctx, meetingId, f, ok)
    }

    fun remove(ctx: Context, meetingId: String, name: String) {
        File(MeetingRepo.dir(ctx, meetingId), name).delete()
        MeetingRepo.update(ctx, meetingId) { it.photos.remove(name) }
    }
}
