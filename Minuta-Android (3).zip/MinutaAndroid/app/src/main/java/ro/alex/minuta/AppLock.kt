package ro.alex.minuta

import android.app.Activity
import android.app.Application
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL

/** Fingerprint / face / PIN lock for the whole app. Locks again after 1 minute in the background. */
object AppLock {
    private const val TIMEOUT_MS = 60_000L

    @Volatile var unlocked = false
    @Volatile var showing = false
    private var started = 0
    private var backgroundAt = 0L

    fun enabled(ctx: Context) = Prefs.raw(ctx, "lock_enabled") == "1"

    fun needsUnlock(ctx: Context) = enabled(ctx) && !unlocked

    /** True if the phone has a fingerprint, face or screen lock we can use. */
    fun available(ctx: Context): Boolean =
        if (Build.VERSION.SDK_INT >= 30) {
            BiometricManager.from(ctx).canAuthenticate(BIOMETRIC_WEAK or DEVICE_CREDENTIAL) == BiometricManager.BIOMETRIC_SUCCESS
        } else {
            ctx.getSystemService(KeyguardManager::class.java).isDeviceSecure
        }

    fun install(app: Application) {
        app.registerActivityLifecycleCallbacks(object : Application.ActivityLifecycleCallbacks {
            override fun onActivityStarted(activity: Activity) {
                if (started == 0 && backgroundAt > 0 && SystemClock.elapsedRealtime() - backgroundAt > TIMEOUT_MS) {
                    unlocked = false
                }
                started++
            }

            override fun onActivityStopped(activity: Activity) {
                started = (started - 1).coerceAtLeast(0)
                if (started == 0) backgroundAt = SystemClock.elapsedRealtime()
            }

            override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) {}
            override fun onActivityResumed(activity: Activity) {}
            override fun onActivityPaused(activity: Activity) {}
            override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) {}
            override fun onActivityDestroyed(activity: Activity) {}
        })
    }
}

class MinutaApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppLock.install(this)
        try {
            Notifier.ensureChannels(this)
        } catch (e: Exception) {
            // Channels are created again when first used.
        }
        try {
            DailyWorker.schedule(this)
        } catch (e: Exception) {
            // Reminders are a bonus; never block the app.
        }
    }
}

/** Every screen with meeting data extends this, so it asks for unlock when needed. */
open class LockedActivity : AppCompatActivity() {
    override fun onStart() {
        super.onStart()
        if (AppLock.needsUnlock(this) && !AppLock.showing) {
            AppLock.showing = true
            startActivity(Intent(this, LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION))
        }
    }
}
