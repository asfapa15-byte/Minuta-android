package ro.alex.minuta

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.View
import android.widget.RemoteViews

/**
 * Home-screen widget: one-tap recording, the live timer while recording,
 * and the next open actions with their deadlines.
 */
class MinutaWidget : AppWidgetProvider() {

    override fun onUpdate(ctx: Context, manager: AppWidgetManager, ids: IntArray) {
        for (id in ids) manager.updateAppWidget(id, build(ctx))
    }

    companion object {
        /** Redraws every Minuta widget on the home screen. Cheap; safe to call often. */
        fun refresh(ctx: Context) {
            try {
                val manager = AppWidgetManager.getInstance(ctx) ?: return
                val ids = manager.getAppWidgetIds(ComponentName(ctx, MinutaWidget::class.java))
                if (ids.isEmpty()) return
                val views = build(ctx)
                for (id in ids) manager.updateAppWidget(id, views)
            } catch (e: Exception) {
                // A widget problem must never break the app.
            }
        }

        private fun activity(ctx: Context, code: Int, intent: Intent): PendingIntent =
            PendingIntent.getActivity(
                ctx, code, intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

        private fun build(ctx: Context): RemoteViews {
            val v = RemoteViews(ctx.packageName, R.layout.widget_minuta)
            val rec = RecordingService.state.value
            val recording = rec.meetingId != null

            v.setOnClickPendingIntent(R.id.w_header, activity(ctx, 21, Intent(ctx, MainActivity::class.java)))

            if (recording) {
                v.setViewVisibility(R.id.w_chrono, View.VISIBLE)
                v.setChronometer(R.id.w_chrono, SystemClock.elapsedRealtime() - rec.elapsedMs, null, !rec.paused)
                v.setTextViewText(R.id.w_status, if (rec.paused) "În pauză" else "● Se înregistrează")
                v.setTextViewText(R.id.w_button, "Deschide ședința")
                v.setOnClickPendingIntent(R.id.w_button, activity(ctx, 22, Intent(ctx, RecordActivity::class.java)))
            } else {
                v.setViewVisibility(R.id.w_chrono, View.GONE)
                v.setTextViewText(R.id.w_button, "●  Ședință nouă")
                v.setOnClickPendingIntent(
                    R.id.w_button,
                    activity(ctx, 23, Intent(ctx, RecordActivity::class.java).setAction(RecordActivity.ACTION_QUICK_START)),
                )
            }

            val meetings = try {
                MeetingRepo.all(ctx)
            } catch (e: Exception) {
                emptyList()
            }
            val toReview = meetings.count {
                it.status == Status.DONE && it.emailSentAt == 0L && it.emailTo.isNotBlank() && it.emailError == null
            }
            val processing = meetings.count {
                it.status == Status.PENDING || it.status == Status.TRANSCRIBING || it.status == Status.SUMMARIZING
            }
            if (!recording) {
                v.setTextViewText(
                    R.id.w_status,
                    when {
                        processing > 0 -> "Se pregătește minuta…"
                        toReview == 1 -> "1 minută de verificat"
                        toReview > 1 -> "$toReview minute de verificat"
                        else -> ""
                    }
                )
            }

            val today = Format.todayIso()
            val open = meetings.filter { it.status == Status.DONE }
                .flatMap { m -> m.actions.filter { !it.done } }
                .sortedBy { it.dueDate.ifEmpty { "9999" } }
            val lines = listOf(R.id.w_a1, R.id.w_a2, R.id.w_a3)
            v.setOnClickPendingIntent(R.id.w_actions, activity(ctx, 24, Intent(ctx, ActionsActivity::class.java)))

            if (AppLock.enabled(ctx)) {
                // The app is locked: don't show meeting details on the home screen.
                v.setTextViewText(R.id.w_count, if (open.isEmpty()) "Nicio acțiune deschisă" else "${open.size} acțiuni deschise")
                v.setTextViewText(R.id.w_a1, "Deschide aplicația pentru detalii.")
                v.setViewVisibility(R.id.w_a1, View.VISIBLE)
                v.setViewVisibility(R.id.w_a2, View.GONE)
                v.setViewVisibility(R.id.w_a3, View.GONE)
                return v
            }

            v.setTextViewText(
                R.id.w_count,
                when (open.size) {
                    0 -> "Nicio acțiune deschisă"
                    1 -> "1 acțiune deschisă"
                    else -> "${open.size} acțiuni deschise"
                }
            )
            lines.forEachIndexed { i, id ->
                val a = open.getOrNull(i)
                if (a == null) {
                    v.setViewVisibility(id, View.GONE)
                } else {
                    val due = when {
                        a.dueDate.isEmpty() -> ""
                        a.dueDate < today -> "⚠ " + Format.isoToShort(a.dueDate).take(5) + " · "
                        a.dueDate == today -> "Azi · "
                        else -> Format.isoToShort(a.dueDate).take(5) + " · "
                    }
                    v.setTextViewText(id, "$due${a.task} (${a.owner})")
                    v.setViewVisibility(id, View.VISIBLE)
                }
            }
            return v
        }
    }
}
