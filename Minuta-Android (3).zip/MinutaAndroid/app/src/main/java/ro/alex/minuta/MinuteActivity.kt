package ro.alex.minuta

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.widget.CheckBox
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.progressindicator.LinearProgressIndicator
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MinuteActivity : LockedActivity() {

    companion object {
        private const val EXTRA_ID = "id"
        fun intent(ctx: Context, id: String): Intent =
            Intent(ctx, MinuteActivity::class.java).putExtra(EXTRA_ID, id)
    }

    private lateinit var id: String
    private lateinit var content: LinearLayout
    private var showTranscript = false
    private var current: Meeting? = null
    private var pendingPhoto: File? = null
    private var sending = false

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingPhoto ?: return@registerForActivityResult
        pendingPhoto = null
        if (Photos.keep(this, id, f, ok)) photoAdded()
    }

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null && Photos.import(this, id, uri)) photoAdded()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        id = intent.getStringExtra(EXTRA_ID) ?: run { finish(); return }
        setContentView(R.layout.activity_minute)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }
        content = findViewById(R.id.content)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                MeetingRepo.changes.collect { render() }
            }
        }
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun text(s: String, style: Int, top: Int = 0, color: Int? = null): TextView =
        TextView(this).apply {
            setTextAppearance(style)
            text = s
            setTextIsSelectable(true)
            color?.let { setTextColor(it) }
            setPadding(0, dp(top), 0, 0)
        }

    private fun heading(s: String) = text(s, com.google.android.material.R.style.TextAppearance_Material3_TitleMedium, 24)
        .also { it.setTextColor(ContextCompat.getColor(this, R.color.teal)) }

    private fun body(s: String, top: Int = 6) = text(s, com.google.android.material.R.style.TextAppearance_Material3_BodyLarge, top)

    private fun muted(s: String, top: Int = 2) =
        text(s, com.google.android.material.R.style.TextAppearance_Material3_BodyMedium, top, ContextCompat.getColor(this, R.color.muted))

    private fun outlined(label: String, onClick: () -> Unit) =
        MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = label
            setOnClickListener { onClick() }
        }

    private fun row(vararg views: android.view.View): LinearLayout {
        val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        views.forEachIndexed { i, v ->
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            if (i > 0) lp.marginStart = dp(10)
            r.addView(v, lp)
        }
        return r
    }

    private fun render() {
        val m = MeetingRepo.get(this, id) ?: run { finish(); return }
        current = m
        val l = m.labels()
        invalidateOptionsMenu()
        content.removeAllViews()

        content.addView(text(m.displayTitle(), com.google.android.material.R.style.TextAppearance_Material3_HeadlineSmall))
        val meta = mutableListOf(Format.date(m.createdAt))
        if (m.durationMs > 0) meta.add(Format.duration(m.durationMs))
        if (m.minuteLang == "en") meta.add("English")
        content.addView(muted(meta.joinToString(" · "), 4))
        if (m.participants.isNotBlank()) content.addView(muted("${l.participants}: ${m.participants}"))

        val running = Processor.isRunning(m.id)
        if (m.status == Status.RECORDING) {
            content.addView(body("Ședința se înregistrează încă.", 20))
            return
        }
        if (running) {
            val label = if (m.status == Status.SUMMARIZING) "Se scrie minuta… (la ședințe lungi poate dura câteva minute)" else {
                val done = m.segmentTranscripts.size
                val total = m.segments.size
                if (total > 1) "Se transcrie audio ($done din $total părți)…" else "Se transcrie audio…"
            }
            content.addView(stepper(if (m.status == Status.SUMMARIZING) 1 else 0))
            content.addView(body(label, 14))
            content.addView(LinearProgressIndicator(this).apply {
                isIndeterminate = true
                trackCornerRadius = dp(4)
                setIndicatorColor(ContextCompat.getColor(this@MinuteActivity, R.color.accent))
                setPadding(0, dp(10), 0, 0)
            })
            content.addView(muted("Poți închide aplicația; primești o notificare când e gata.", 10))
        } else if (m.status != Status.DONE) {
            if (m.status == Status.ERROR && m.error != null) {
                content.addView(text(m.error!!, com.google.android.material.R.style.TextAppearance_Material3_BodyMedium, 20,
                    ContextCompat.getColor(this, R.color.error)))
            } else {
                content.addView(body("Minuta nu a fost generată încă.", 20))
            }
            val retry = MaterialButton(this).apply {
                text = "Reîncearcă"
                setOnClickListener { RecordingService.send(this@MinuteActivity, RecordingService.ACTION_PROCESS, m.id) }
            }
            if (Prefs.hasKeys(this)) content.addView(row(retry))
            else content.addView(row(retry, outlined("Setări") { startActivity(Intent(this, SettingsActivity::class.java)) }))
        }

        if (m.status == Status.DONE) emailCard(m)

        if (m.status == Status.DONE || m.summary.isNotBlank()) {
            content.addView(heading(l.summary))
            content.addView(body(m.summary.ifBlank { "—" }))

            content.addView(heading(l.decisions))
            if (m.decisions.isEmpty()) content.addView(muted(l.noDecisions, 6))
            for (d in m.decisions) content.addView(body("•  $d"))

            content.addView(heading(l.actions))
            if (m.actions.isEmpty()) content.addView(muted(l.noActions, 6))
            for (a in m.actions) content.addView(actionView(m, a, l))
        }

        if (m.photos.isNotEmpty()) {
            content.addView(heading(l.photos))
            val strip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val dir = MeetingRepo.dir(this, m.id)
            for (p in m.photos) {
                val bmp = ImageUtil.load(File(dir, p), 400) ?: continue
                val img = ImageView(this).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    contentDescription = "Poză din ședință"
                    setOnLongClickListener {
                        MaterialAlertDialogBuilder(this@MinuteActivity)
                            .setTitle("Ștergi poza?")
                            .setNegativeButton("Renunță", null)
                            .setPositiveButton("Șterge") { _, _ -> Photos.remove(this@MinuteActivity, m.id, p) }
                            .show()
                        true
                    }
                }
                strip.addView(img, LinearLayout.LayoutParams(dp(120), dp(120)).apply { marginEnd = dp(8) })
            }
            content.addView(HorizontalScrollView(this).apply { addView(strip); setPadding(0, dp(6), 0, 0) })
            content.addView(muted("Ține apăsat pe o poză ca s-o ștergi. După ce adaugi sau ștergi poze, regenerează minuta.", 6))
        }

        if (m.transcript.isNotBlank()) {
            content.addView(heading(l.transcript))
            content.addView(MaterialButton(this, null, androidx.appcompat.R.attr.borderlessButtonStyle).apply {
                text = if (showTranscript) "Ascunde transcrierea" else "Arată transcrierea completă"
                setOnClickListener { showTranscript = !showTranscript; render() }
            })
            if (showTranscript) content.addView(body(m.transcript, 4))
        }
    }

    /** Three steps (transcript, minute, check), with the current one highlighted. */
    private fun stepper(current: Int): LinearLayout {
        val names = listOf("Transcriere", "Minută", "Verificare")
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(22), 0, 0)
        }
        names.forEachIndexed { i, n ->
            val (fg, bg) = when {
                i < current -> R.color.on_accent to R.color.success
                i == current -> R.color.on_accent to R.color.accent
                else -> R.color.muted to R.color.surface_alt
            }
            val pill = TextView(this).apply {
                text = if (i < current) "✓ $n" else "${i + 1}  $n"
                setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_LabelLarge)
                setTextColor(ContextCompat.getColor(this@MinuteActivity, fg))
                setBackgroundResource(R.drawable.bg_pill)
                backgroundTintList = android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this@MinuteActivity, bg))
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            if (i > 0) lp.marginStart = dp(6)
            bar.addView(pill, lp)
        }
        return bar
    }

    private fun actionView(m: Meeting, a: ActionItem, l: Labels): LinearLayout {
        val box = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(10), 0, 0) }
        val check = CheckBox(this).apply {
            isChecked = a.done
            contentDescription = "Gata"
            setOnCheckedChangeListener { v, on ->
                Ui.confirm(v)
                MeetingRepo.update(this@MinuteActivity, m.id) { mm -> mm.actions.firstOrNull { it.id == a.id }?.done = on }
            }
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(body(a.task, 0).apply { alpha = if (a.done) 0.5f else 1f })
        texts.addView(muted("${l.owner}: ${a.owner}  ·  ${l.due}: ${a.due}"))
        box.addView(check)
        box.addView(texts, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return box
    }

    /** Where the e-mail stands: sent, waiting for your check, or failed. */
    private fun emailCard(m: Meeting) {
        val lines = mutableListOf<android.view.View>()
        when {
            m.emailSentAt > 0 -> {
                lines.add(muted("✉ Trimisă la ${m.emailTo} (${Format.date(m.emailSentAt)})", 0))
                if (m.tasksSentAt > 0) lines.add(muted("Fiecare responsabil și-a primit sarcinile pe e-mail.", 4))
            }
            m.emailError != null -> {
                lines.add(text("✉ E-mailul nu a plecat: ${m.emailError}", com.google.android.material.R.style.TextAppearance_Material3_BodyMedium,
                    0, ContextCompat.getColor(this, R.color.error)))
                lines.add(row(outlined("Verifică") { startActivity(EditMinuteActivity.intent(this, m.id)) },
                    MaterialButton(this).apply { text = "Retrimite"; setOnClickListener { sendNow(m.id) } }))
            }
            m.emailTo.isNotBlank() && Mailer.ready(this) -> {
                lines.add(body("Minuta e gata de trimis la: ${m.emailTo}", 0))
                lines.add(muted("Verific-o (nume, cifre, termene), apoi trimite-o.", 4))
                lines.add(row(outlined("Verifică și editează") { startActivity(EditMinuteActivity.intent(this, m.id)) },
                    MaterialButton(this).apply { text = "Trimite acum"; setOnClickListener { sendNow(m.id) } }))
            }
            else -> return
        }
        val inner = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            lines.forEach { addView(it) }
        }
        val card = MaterialCardView(this).apply {
            setCardBackgroundColor(ContextCompat.getColor(this@MinuteActivity, R.color.banner_bg))
            strokeWidth = 0
            radius = dp(12).toFloat()
            addView(inner)
        }
        content.addView(card, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(16) })
    }

    private fun sendNow(meetingId: String) {
        if (sending) return
        sending = true
        Toast.makeText(this, "Se trimite…", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch {
            val err = withContext(Dispatchers.IO) { Mailer.sendMinute(applicationContext, meetingId) }
            sending = false
            Toast.makeText(this@MinuteActivity, err ?: "Minuta a fost trimisă.", Toast.LENGTH_LONG).show()
        }
    }

    private fun photoAdded() {
        Toast.makeText(this, "Poză adăugată. Regenerează minuta ca s-o includă.", Toast.LENGTH_LONG).show()
    }

    private fun askAndSend(m: Meeting) {
        if (!Mailer.ready(this)) {
            Toast.makeText(this, "Configurează mai întâi trimiterea pe e-mail în Setări.", Toast.LENGTH_LONG).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        val input = TextInputEditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            setText(m.emailTo.ifBlank { Prefs.raw(this@MinuteActivity, "last_recipients") })
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(input)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Trimite minuta pe e-mail")
            .setMessage("Adresele, separate prin virgulă:")
            .setView(box)
            .setNegativeButton("Renunță", null)
            .setPositiveButton("Trimite") { _, _ ->
                val text = input.text?.toString().orEmpty()
                val bad = Mailer.invalidAddresses(text)
                val to = Mailer.parseAddresses(text)
                if (to.isEmpty() || bad.isNotEmpty()) {
                    Toast.makeText(this, if (to.isEmpty()) "Nicio adresă." else "Adresă greșită: ${bad.joinToString()}", Toast.LENGTH_LONG).show()
                    return@setPositiveButton
                }
                val joined = to.joinToString(", ")
                Prefs.save(this, mapOf("last_recipients" to joined))
                MeetingRepo.update(this, m.id) { it.emailTo = joined; it.emailError = null }
                sendNow(m.id)
            }
            .show()
    }

    private fun sharePdf(m: Meeting) {
        lifecycleScope.launch {
            val file = withContext(Dispatchers.IO) { runCatching { PdfMaker.makeFile(applicationContext, m) }.getOrNull() }
            if (file == null) {
                Toast.makeText(this@MinuteActivity, "Nu am putut crea PDF-ul.", Toast.LENGTH_LONG).show()
                return@launch
            }
            val uri = Photos.uriFor(this@MinuteActivity, file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "${m.labels().subjectPrefix}: ${m.displayTitle()}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, "Trimite PDF-ul"))
        }
    }

    private fun capturePhoto() {
        val f = Photos.newFile(this, id)
        pendingPhoto = f
        try {
            takePhoto.launch(Photos.uriFor(this, f))
        } catch (e: Exception) {
            pendingPhoto = null
            Toast.makeText(this, "Nu am găsit o aplicație de cameră.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.minute, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        val done = current?.status == Status.DONE
        for (item in listOf(R.id.action_share, R.id.action_copy, R.id.action_email, R.id.action_edit, R.id.action_pdf, R.id.action_regenerate)) {
            menu.findItem(item)?.isVisible = done
        }
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val m = current ?: return super.onOptionsItemSelected(item)
        when (item.itemId) {
            R.id.action_share -> {
                val send = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_SUBJECT, "${m.labels().subjectPrefix}: ${m.displayTitle()}")
                    putExtra(Intent.EXTRA_TEXT, m.toShareText())
                }
                startActivity(Intent.createChooser(send, "Trimite minuta"))
            }
            R.id.action_edit -> startActivity(EditMinuteActivity.intent(this, m.id))
            R.id.action_email -> askAndSend(m)
            R.id.action_pdf -> sharePdf(m)
            R.id.action_photo_camera -> capturePhoto()
            R.id.action_photo_gallery -> pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            R.id.action_copy -> {
                val cm = getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("Minuta", m.toShareText()))
                Toast.makeText(this, "Minuta a fost copiată", Toast.LENGTH_SHORT).show()
            }
            R.id.action_regenerate -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Regenerezi minuta?")
                    .setMessage("Modificările făcute de mână în minută se pierd. Transcrierea rămâne.")
                    .setNegativeButton("Renunță", null)
                    .setPositiveButton("Regenerează") { _, _ ->
                        MeetingRepo.update(this, m.id) { it.status = Status.PENDING }
                        RecordingService.send(this, RecordingService.ACTION_PROCESS, m.id)
                    }
                    .show()
            }
            R.id.action_delete -> {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Ștergi ședința?")
                    .setMessage("Se șterg minuta, transcrierea, pozele și înregistrarea audio.")
                    .setNegativeButton("Renunță", null)
                    .setPositiveButton("Șterge") { _, _ ->
                        if (RecordingService.state.value.meetingId == m.id || Processor.isRunning(m.id)) {
                            Toast.makeText(this, "Așteaptă să se termine procesarea.", Toast.LENGTH_SHORT).show()
                        } else {
                            MeetingRepo.delete(this, m.id)
                            finish()
                        }
                    }
                    .show()
            }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
