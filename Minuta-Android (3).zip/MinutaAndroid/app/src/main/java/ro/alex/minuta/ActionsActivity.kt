package ro.alex.minuta

import android.content.res.ColorStateList
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.Bundle
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.chip.Chip
import kotlinx.coroutines.launch

/** Every action from every meeting, by deadline. Swipe right (or tick) when done. */
class ActionsActivity : LockedActivity() {

    private sealed class Row {
        class Header(val title: String, val count: Int, val late: Boolean) : Row()
        class Item(val meeting: Meeting, val action: ActionItem) : Row()
    }

    private lateinit var list: RecyclerView
    private lateinit var empty: TextView
    private var showDone = false
    private var byPerson = false
    private var firstLoad = true
    private val rows = mutableListOf<Row>()
    private val adapter = RowsAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_actions)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))
        list = findViewById(R.id.list)
        empty = findViewById(R.id.empty)
        list.layoutManager = LinearLayoutManager(this)
        list.adapter = adapter
        ItemTouchHelper(SwipeToggle()).attachToRecyclerView(list)

        findViewById<Chip>(R.id.chip_by_person).setOnCheckedChangeListener { v, on ->
            Ui.tick(v)
            byPerson = on
            render()
        }
        findViewById<Chip>(R.id.chip_show_done).setOnCheckedChangeListener { v, on ->
            Ui.tick(v)
            showDone = on
            render()
        }
        Ui.bottomNav(this, findViewById<BottomNavigationView>(R.id.bottom_nav), R.id.nav_actions)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                MeetingRepo.changes.collect { render() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        findViewById<BottomNavigationView>(R.id.bottom_nav).menu.findItem(R.id.nav_actions)?.isChecked = true
    }

    private fun toggle(m: Meeting, a: ActionItem, done: Boolean) {
        MeetingRepo.update(this, m.id) { mm -> mm.actions.firstOrNull { it.id == a.id }?.done = done }
    }

    @android.annotation.SuppressLint("NotifyDataSetChanged")
    private fun render() {
        val today = Format.todayIso()
        val weekEnd = Format.todayIso(7)
        val all = MeetingRepo.all(this).filter { it.status == Status.DONE }
            .flatMap { m -> m.actions.map { m to it } }
            .filter { showDone || !it.second.done }

        val groups: List<Pair<String, List<Pair<Meeting, ActionItem>>>> = if (byPerson) {
            all.groupBy { it.second.owner.ifBlank { "Nestabilit" } }.toSortedMap().map { (k, v) ->
                k to v.sortedBy { it.second.dueDate.ifEmpty { "9999" } }
            }
        } else {
            fun bucket(a: ActionItem) = when {
                a.done -> 5
                a.dueDate.isEmpty() -> 4
                a.dueDate < today -> 0
                a.dueDate == today -> 1
                a.dueDate <= weekEnd -> 2
                else -> 3
            }
            val names = listOf("Întârziate", "Azi", "În următoarele 7 zile", "Mai târziu", "Fără termen", "Gata")
            all.groupBy { bucket(it.second) }.toSortedMap().map { (k, v) ->
                names[k] to v.sortedBy { it.second.dueDate.ifEmpty { "9999" } }
            }
        }

        rows.clear()
        for ((title, items) in groups) {
            rows.add(Row.Header(title, items.size, title == "Întârziate"))
            for ((m, a) in items) rows.add(Row.Item(m, a))
        }
        adapter.notifyDataSetChanged()
        if (firstLoad && rows.isNotEmpty()) {
            firstLoad = false
            list.scheduleLayoutAnimation()
        }
        empty.visibility = if (rows.isEmpty()) View.VISIBLE else View.GONE
        val open = all.count { !it.second.done }
        supportActionBar?.subtitle = if (open == 0) null else if (open == 1) "1 deschisă" else "$open deschise"
    }

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private inner class RowsAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        inner class HeaderVH(val text: TextView) : RecyclerView.ViewHolder(text)
        inner class ItemVH(v: View) : RecyclerView.ViewHolder(v) {
            val check: CheckBox = v.findViewById(R.id.check)
            val task: TextView = v.findViewById(R.id.task)
            val meta: TextView = v.findViewById(R.id.meta)
            val due: TextView = v.findViewById(R.id.due)
        }

        override fun getItemCount() = rows.size
        override fun getItemViewType(position: Int) = if (rows[position] is Row.Header) 0 else 1

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
            if (viewType == 0) {
                HeaderVH(TextView(parent.context).apply {
                    setTextAppearance(com.google.android.material.R.style.TextAppearance_Material3_TitleSmall)
                    setPadding(dp(8), dp(18), dp(8), dp(6))
                    layoutParams = RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                })
            } else {
                ItemVH(LayoutInflater.from(parent.context).inflate(R.layout.item_action, parent, false))
            }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            when (val row = rows[position]) {
                is Row.Header -> {
                    val h = holder as HeaderVH
                    h.text.text = "${row.title}  ·  ${row.count}"
                    h.text.setTextColor(ContextCompat.getColor(this@ActionsActivity, if (row.late) R.color.error else R.color.muted))
                }
                is Row.Item -> {
                    val h = holder as ItemVH
                    val a = row.action
                    val m = row.meeting
                    h.task.text = a.task
                    h.task.alpha = if (a.done) 0.45f else 1f
                    h.task.paintFlags = if (a.done) h.task.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                    else h.task.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                    h.meta.text = (if (byPerson) "" else "${a.owner} · ") + m.displayTitle()
                    h.check.setOnCheckedChangeListener(null)
                    h.check.isChecked = a.done
                    h.check.setOnCheckedChangeListener { v, on ->
                        Ui.confirm(v)
                        toggle(m, a, on)
                    }
                    val today = Format.todayIso()
                    val (fg, bg) = when {
                        a.done -> R.color.success to R.color.success_soft
                        a.dueDate.isNotEmpty() && a.dueDate < today -> R.color.error to R.color.accent_soft
                        a.dueDate == today -> R.color.warning to R.color.warning_soft
                        else -> R.color.muted to R.color.surface_alt
                    }
                    h.due.text = if (a.dueDate.isNotEmpty()) Format.isoToShort(a.dueDate).substring(0, 5) else a.due.take(14)
                    h.due.setTextColor(ContextCompat.getColor(this@ActionsActivity, fg))
                    h.due.backgroundTintList = ColorStateList.valueOf(ContextCompat.getColor(this@ActionsActivity, bg))
                    h.itemView.setOnClickListener { startActivity(MinuteActivity.intent(this@ActionsActivity, m.id)) }
                }
            }
        }
    }

    /** Swipe an action to the right to tick it (or untick it). */
    private inner class SwipeToggle : ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
        private val green = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ContextCompat.getColor(this@ActionsActivity, R.color.success) }
        private val icon = ContextCompat.getDrawable(this@ActionsActivity, R.drawable.ic_check)?.mutate()?.apply { setTint(0xFFFFFFFF.toInt()) }
        private val rect = RectF()

        override fun onMove(rv: RecyclerView, vh: RecyclerView.ViewHolder, target: RecyclerView.ViewHolder) = false

        override fun getSwipeDirs(rv: RecyclerView, vh: RecyclerView.ViewHolder): Int =
            if (rows.getOrNull(vh.bindingAdapterPosition) is Row.Item) ItemTouchHelper.RIGHT else 0

        override fun onSwiped(vh: RecyclerView.ViewHolder, direction: Int) {
            val row = rows.getOrNull(vh.bindingAdapterPosition) as? Row.Item ?: return
            Ui.confirm(vh.itemView)
            toggle(row.meeting, row.action, !row.action.done)
        }

        override fun onChildDraw(
            c: Canvas, rv: RecyclerView, vh: RecyclerView.ViewHolder,
            dX: Float, dY: Float, actionState: Int, isCurrentlyActive: Boolean,
        ) {
            val v = vh.itemView
            val d = resources.displayMetrics.density
            if (dX > 0) {
                rect.set(v.left + 4 * d, v.top + 4 * d, v.left + dX, v.bottom - 4 * d)
                c.drawRoundRect(rect, 16 * d, 16 * d, green)
                icon?.let {
                    val size = (24 * d).toInt()
                    val top = v.top + (v.height - size) / 2
                    val left = v.left + (24 * d).toInt()
                    it.setBounds(left, top, left + size, top + size)
                    if (dX > size * 2) it.draw(c)
                }
            }
            super.onChildDraw(c, rv, vh, dX, dY, actionState, isCurrentlyActive)
        }
    }
}
