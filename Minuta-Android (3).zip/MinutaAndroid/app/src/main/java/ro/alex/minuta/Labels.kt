package ro.alex.minuta

/** Section names for the minute, in the language the minute is written in. */
data class Labels(
    val minute: String,
    val untitled: String,
    val date: String,
    val duration: String,
    val participants: String,
    val summary: String,
    val decisions: String,
    val actions: String,
    val transcript: String,
    val owner: String,
    val due: String,
    val action: String,
    val noDecisions: String,
    val noActions: String,
    val tbd: String,
    val photos: String,
    val subjectPrefix: String,
    val tasksSubject: String,
    val tasksIntro: String,
    val fromMeeting: String,
) {
    companion object {
        val RO = Labels(
            minute = "Minută ședință",
            untitled = "Ședință fără titlu",
            date = "Data",
            duration = "Durată",
            participants = "Participanți",
            summary = "Rezumat",
            decisions = "Decizii",
            actions = "Acțiuni",
            transcript = "Transcriere",
            owner = "Responsabil",
            due = "Termen",
            action = "Acțiune",
            noDecisions = "Nicio decizie consemnată.",
            noActions = "Nicio acțiune consemnată.",
            tbd = "Nestabilit",
            photos = "Imagini din ședință",
            subjectPrefix = "Minută ședință",
            tasksSubject = "Sarcinile tale din ședința",
            tasksIntro = "Bună ziua, mai jos sunt acțiunile care îți revin din ședința",
            fromMeeting = "Ședința",
        )
        val EN = Labels(
            minute = "Meeting minutes",
            untitled = "Untitled meeting",
            date = "Date",
            duration = "Duration",
            participants = "Participants",
            summary = "Summary",
            decisions = "Decisions",
            actions = "Action items",
            transcript = "Transcript",
            owner = "Owner",
            due = "Due",
            action = "Action",
            noDecisions = "No decisions recorded.",
            noActions = "No action items recorded.",
            tbd = "TBD",
            photos = "Images from the meeting",
            subjectPrefix = "Meeting minutes",
            tasksSubject = "Your action items from",
            tasksIntro = "Hello, below are the action items assigned to you from",
            fromMeeting = "Meeting",
        )

        fun of(lang: String) = if (lang == "en") EN else RO
    }
}
