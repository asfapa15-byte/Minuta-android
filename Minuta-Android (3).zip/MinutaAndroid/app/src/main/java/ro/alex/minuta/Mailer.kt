package ro.alex.minuta

import android.content.Context
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Base64
import java.util.Date
import java.util.Locale
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

class MailException(message: String, val permanent: Boolean) : IOException(message)

class Attachment(val name: String, val mime: String, val bytes: ByteArray)

/**
 * Sends e-mail from a Gmail account (smtp.gmail.com, SSL, port 465),
 * logging in with a Google "app password". No server and no extra library.
 */
object Mailer {

    private val EMAIL = Regex("^[^@\\s,;]+@[^@\\s,;]+\\.[^@\\s,;]+$")
    private const val TEAL = "#0B5D63"

    fun parseAddresses(s: String): List<String> =
        s.split(',', ';', ' ', '\n', '\t').map { it.trim() }.filter { it.isNotEmpty() }.distinct()

    fun invalidAddresses(s: String): List<String> = parseAddresses(s).filterNot { EMAIL.matches(it) }

    fun ready(ctx: Context) =
        Prefs.raw(ctx, "email_enabled") == "1" &&
            Prefs.raw(ctx, "gmail_address").isNotEmpty() &&
            Prefs.raw(ctx, "gmail_app_password").isNotEmpty()

    // ------------------------------------------------------------------ minute

    /** Sends the minute (with PDF) and records the result on the meeting. Returns an error message, or null. */
    fun sendMinute(ctx: Context, id: String): String? {
        val m = MeetingRepo.get(ctx, id) ?: return "Ședința nu mai există."
        val l = m.labels()
        val error: String? = try {
            if (!ready(ctx)) throw MailException("Trimiterea pe e-mail nu e configurată în Setări.", true)
            val to = parseAddresses(m.emailTo)
            if (to.isEmpty()) throw MailException("Nu ai ales niciun destinatar.", true)
            val bad = invalidAddresses(m.emailTo)
            if (bad.isNotEmpty()) throw MailException("Adresă de e-mail greșită: ${bad.joinToString()}", true)
            val subject = "${l.subjectPrefix}: ${m.displayTitle()} | ${Format.shortDate(m.createdAt)}"
            val attachments = mutableListOf<Attachment>()
            try {
                attachments.add(Attachment(PdfMaker.fileName(m), "application/pdf", PdfMaker.make(ctx, m)))
            } catch (e: Exception) {
                // Send without PDF rather than not at all.
            }
            sendWithRetry(ctx, to, subject, m.toShareText() + textSignature(ctx), wrapHtml(ctx, minuteHtml(m)), attachments)
            null
        } catch (e: MailException) {
            e.message
        } catch (e: IOException) {
            "Nu s-a putut trimite e-mailul: ${e.message ?: "fără conexiune?"}"
        }
        MeetingRepo.update(ctx, id) {
            if (error == null) {
                it.emailSentAt = System.currentTimeMillis()
                it.emailError = null
            } else {
                it.emailError = error
            }
        }
        if (error == null && Prefs.tasksPerPerson(ctx)) {
            try {
                sendTasks(ctx, id)
            } catch (e: Exception) {
                // The minute itself went out; task e-mails are a bonus.
            }
        }
        return error
    }

    // ------------------------------------------------------------------ tasks per person

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(Locale.ROOT).trim(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")

    /** Finds an e-mail for an action owner, from the meeting's calendar guests and the team address book. */
    fun resolveEmail(ctx: Context, owner: String, m: Meeting): String? {
        val o = norm(owner)
        if (o.isEmpty() || o == norm(m.labels().tbd)) return null
        if (EMAIL.matches(owner.trim())) return owner.trim()
        val book = LinkedHashMap<String, String>()
        book.putAll(Prefs.teamContacts(ctx))
        book.putAll(m.contacts)
        val first = o.split(' ').first()
        for ((name, mail) in book) {
            val n = norm(name)
            if (n == o || n.split(' ').first() == first || n.contains(o) || o.contains(n)) return mail
        }
        return null
    }

    /** E-mails each owner only their own open actions. Returns how many people got one. */
    fun sendTasks(ctx: Context, id: String): Int {
        val m = MeetingRepo.get(ctx, id) ?: return 0
        if (!ready(ctx)) return 0
        val l = m.labels()
        val byEmail = LinkedHashMap<String, MutableList<ActionItem>>()
        for (a in m.actions.filter { !it.done }) {
            val mail = resolveEmail(ctx, a.owner, m) ?: continue
            byEmail.getOrPut(mail.lowercase()) { mutableListOf() }.add(a)
        }
        var sent = 0
        for ((mail, items) in byEmail) {
            val subject = "${l.tasksSubject} „${m.displayTitle()}” | ${Format.shortDate(m.createdAt)}"
            val html = StringBuilder()
            html.append("<p>").append(esc(l.tasksIntro)).append(" <b>").append(esc(m.displayTitle()))
                .append("</b> (").append(esc(Format.date(m.createdAt, m.minuteLang))).append("):</p>")
            html.append(actionsTable(items, l, showOwner = false))
            val text = StringBuilder(l.tasksIntro).append(' ').append(m.displayTitle()).append(":\n\n")
            for (a in items) text.append("- ").append(a.task).append(" (").append(l.due).append(": ").append(a.due).append(")\n")
            sendWithRetry(ctx, listOf(mail), subject, text.toString() + textSignature(ctx), wrapHtml(ctx, html.toString()), emptyList())
            sent++
        }
        if (sent > 0) MeetingRepo.update(ctx, id) { it.tasksSentAt = System.currentTimeMillis() }
        return sent
    }

    // ------------------------------------------------------------------ weekly digest

    /** Monday summary of all open actions, grouped by person, sent to your own address. */
    fun sendDigest(ctx: Context): String? = try {
        val me = Prefs.myAddress(ctx).ifEmpty { Prefs.raw(ctx, "gmail_address") }
        val today = Format.todayIso()
        val open = MeetingRepo.all(ctx).flatMap { mt -> mt.actions.filter { !it.done }.map { mt to it } }
        val html = StringBuilder()
        html.append("<p>Rezumatul săptămânii – acțiuni deschise: <b>").append(open.size).append("</b></p>")
        if (open.isEmpty()) {
            html.append("<p>Nu există acțiuni deschise. Săptămână bună!</p>")
        } else {
            val td = "style=\"padding:6px 8px;border-bottom:1px solid #dfe5e6;vertical-align:top\""
            for ((owner, list) in open.groupBy { it.second.owner.ifBlank { "Nestabilit" } }.toSortedMap()) {
                html.append("<h3 style=\"color:$TEAL;margin:20px 0 6px;font-size:16px\">").append(esc(owner))
                    .append(" (").append(list.size).append(")</h3>")
                html.append("<table style=\"border-collapse:collapse;width:100%;font-size:14px\">")
                for ((mt, a) in list.sortedBy { it.second.dueDate.ifEmpty { "9999" } }) {
                    val late = a.dueDate.isNotEmpty() && a.dueDate < today
                    html.append("<tr><td $td>").append(esc(a.task)).append("<br><span style=\"color:#5b6268;font-size:12px\">")
                        .append(esc(mt.displayTitle())).append(" · ").append(Format.shortDate(mt.createdAt)).append("</span></td>")
                        .append("<td style=\"padding:6px 8px;border-bottom:1px solid #dfe5e6;vertical-align:top;white-space:nowrap\">")
                        .append(if (late) "<span style=\"color:#b3261e\"><b>întârziat</b> · " else "<span>")
                        .append(esc(a.due)).append("</span></td></tr>")
                }
                html.append("</table>")
            }
        }
        val text = buildString {
            append("Acțiuni deschise: ").append(open.size).append("\n\n")
            for ((mt, a) in open) append("- ").append(a.owner).append(": ").append(a.task).append(" (").append(a.due)
                .append(") – ").append(mt.displayTitle()).append('\n')
        }
        sendWithRetry(ctx, listOf(me), "Rezumat săptămânal – acțiuni deschise | ${Format.shortDate(System.currentTimeMillis())}",
            text, wrapHtml(ctx, html.toString()), emptyList())
        null
    } catch (e: IOException) {
        e.message ?: "Eroare necunoscută"
    }

    fun sendTest(ctx: Context): String? = try {
        val me = Prefs.myAddress(ctx).ifEmpty { Prefs.raw(ctx, "gmail_address") }
        sendWithRetry(
            ctx, listOf(me), "Minuta – e-mail de test",
            "Trimiterea automată a minutelor funcționează." + textSignature(ctx),
            wrapHtml(ctx, "<p>Trimiterea automată a minutelor funcționează.</p>"),
            emptyList(),
        )
        null
    } catch (e: IOException) {
        e.message ?: "Eroare necunoscută"
    }

    // ------------------------------------------------------------------ HTML

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;")

    private fun textSignature(ctx: Context): String {
        val sig = Prefs.signature(ctx)
        return if (sig.isEmpty()) "" else "\n-- \n$sig\n"
    }

    private fun wrapHtml(ctx: Context, body: String): String {
        val sb = StringBuilder()
        sb.append("<div style=\"font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:1.5;color:#14161a;max-width:720px\">")
        sb.append(body)
        val sig = Prefs.signature(ctx)
        if (sig.isNotEmpty()) {
            sb.append("<div style=\"margin-top:28px;padding-top:10px;border-top:1px solid #dfe5e6;color:#3d4348;font-size:13px\">")
                .append(esc(sig).replace("\n", "<br>")).append("</div>")
        }
        sb.append("</div>")
        return sb.toString()
    }

    private fun actionsTable(items: List<ActionItem>, l: Labels, showOwner: Boolean = true): String {
        val td = "style=\"padding:7px 8px;border-bottom:1px solid #dfe5e6;vertical-align:top\""
        val sb = StringBuilder("<table style=\"border-collapse:collapse;width:100%;font-size:14px\">")
        sb.append("<tr style=\"background:#e6f1f1;text-align:left\"><th $td>").append(l.action).append("</th>")
        if (showOwner) sb.append("<th $td>").append(l.owner).append("</th>")
        sb.append("<th $td>").append(l.due).append("</th></tr>")
        for (a in items) {
            sb.append("<tr><td $td>").append(esc(a.task)).append("</td>")
            if (showOwner) sb.append("<td $td>").append(esc(a.owner)).append("</td>")
            sb.append("<td style=\"padding:7px 8px;border-bottom:1px solid #dfe5e6;vertical-align:top;white-space:nowrap\">")
                .append(esc(a.due)).append("</td></tr>")
        }
        sb.append("</table>")
        return sb.toString()
    }

    fun minuteHtml(m: Meeting): String {
        val l = m.labels()
        val sb = StringBuilder()
        sb.append("<h2 style=\"margin:0 0 4px;color:$TEAL\">").append(esc(m.displayTitle())).append("</h2>")
        val meta = mutableListOf(Format.date(m.createdAt, m.minuteLang))
        if (m.durationMs > 0) meta.add(l.duration.lowercase() + " " + Format.duration(m.durationMs))
        sb.append("<div style=\"color:#5b6268;font-size:13px\">").append(esc(meta.joinToString(" · "))).append("</div>")
        if (m.participants.isNotBlank()) {
            sb.append("<div style=\"color:#5b6268;font-size:13px\">").append(l.participants).append(": ")
                .append(esc(m.participants)).append("</div>")
        }
        fun h(t: String) = sb.append("<h3 style=\"color:$TEAL;margin:22px 0 6px;font-size:16px\">").append(t).append("</h3>")

        h(l.summary)
        sb.append("<p style=\"margin:0\">").append(esc(m.summary.ifBlank { "—" })).append("</p>")

        h(l.decisions)
        if (m.decisions.isEmpty()) {
            sb.append("<p style=\"margin:0;color:#5b6268\">").append(l.noDecisions).append("</p>")
        } else {
            sb.append("<ul style=\"margin:0;padding-left:20px\">")
            for (d in m.decisions) sb.append("<li>").append(esc(d)).append("</li>")
            sb.append("</ul>")
        }

        h(l.actions)
        if (m.actions.isEmpty()) sb.append("<p style=\"margin:0;color:#5b6268\">").append(l.noActions).append("</p>")
        else sb.append(actionsTable(m.actions, l))

        if (m.transcript.isNotBlank()) {
            h(l.transcript)
            sb.append("<div style=\"color:#3d4348;font-size:13px;white-space:pre-wrap\">").append(esc(m.transcript)).append("</div>")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------ SMTP

    private fun sendWithRetry(
        ctx: Context, to: List<String>, subject: String, text: String, html: String, attachments: List<Attachment>,
    ) {
        val from = Prefs.raw(ctx, "gmail_address")
        val pass = Prefs.raw(ctx, "gmail_app_password").replace(" ", "")
        val fromName = Prefs.senderName(ctx)
        val replyTo = Prefs.myAddress(ctx).takeIf { EMAIL.matches(it) && !it.equals(from, true) }
        var last: IOException? = null
        repeat(3) { attempt ->
            try {
                send(from, pass, to, buildMessage(from, fromName, replyTo, to, subject, text, html, attachments))
                return
            } catch (e: MailException) {
                if (e.permanent) throw e
                last = e
            } catch (e: IOException) {
                last = e
            }
            if (attempt < 2) Thread.sleep(5_000L * (attempt + 1))
        }
        throw last ?: IOException("Eroare necunoscută")
    }

    private fun b64(s: String) = Base64.getEncoder().encodeToString(s.toByteArray(Charsets.UTF_8))

    private fun mimeB64(bytes: ByteArray) = Base64.getMimeEncoder().encodeToString(bytes)

    private fun send(from: String, pass: String, to: List<String>, message: String) {
        val socket = SSLSocketFactory.getDefault().createSocket("smtp.gmail.com", 465) as SSLSocket
        socket.soTimeout = 60_000
        socket.use { s ->
            val r = BufferedReader(InputStreamReader(s.inputStream, Charsets.UTF_8))
            val w = BufferedWriter(OutputStreamWriter(s.outputStream, Charsets.UTF_8))

            fun read(vararg ok: Int): String {
                val sb = StringBuilder()
                var line: String
                do {
                    line = r.readLine() ?: throw IOException("Serverul Gmail a închis conexiunea.")
                    sb.append(line).append('\n')
                } while (line.length > 3 && line[3] == '-')
                val code = line.take(3).toIntOrNull() ?: 0
                if (code !in ok) {
                    val reply = sb.toString().trim()
                    if (code == 535 || code == 534) {
                        throw MailException(
                            "Gmail a refuzat logarea. Verifică adresa și parola de aplicație (16 litere) din Setări.", true
                        )
                    }
                    throw MailException("Gmail a răspuns: $reply", code in 500..599)
                }
                return sb.toString()
            }

            fun cmd(c: String, vararg ok: Int) {
                w.write(c)
                w.write("\r\n")
                w.flush()
                read(*ok)
            }

            read(220)
            cmd("EHLO minuta.app", 250)
            cmd("AUTH LOGIN", 334)
            cmd(b64(from), 334)
            cmd(b64(pass), 235)
            cmd("MAIL FROM:<$from>", 250)
            for (t in to) cmd("RCPT TO:<$t>", 250, 251)
            cmd("DATA", 354)
            w.write(message)
            w.write("\r\n.\r\n")
            w.flush()
            read(250)
            try {
                cmd("QUIT", 221)
            } catch (e: IOException) {
                // Already sent; ignore.
            }
        }
    }

    private fun buildMessage(
        from: String, fromName: String, replyTo: String?, to: List<String>,
        subject: String, text: String, html: String, attachments: List<Attachment>,
    ): String {
        val stamp = System.currentTimeMillis()
        val mixed = "minuta-mixed-$stamp"
        val alt = "minuta-alt-$stamp"
        val date = SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss Z", Locale.US).format(Date())
        val sb = StringBuilder()
        fun line(s: String = "") = sb.append(s).append("\r\n")
        line("From: =?UTF-8?B?${b64(fromName)}?= <$from>")
        if (replyTo != null) line("Reply-To: $replyTo")
        line("To: ${to.joinToString(", ")}")
        line("Subject: =?UTF-8?B?${b64(subject)}?=")
        line("Date: $date")
        line("Message-ID: <$stamp.${(Math.random() * 1e9).toLong()}@minuta.app>")
        line("MIME-Version: 1.0")
        if (attachments.isNotEmpty()) {
            line("Content-Type: multipart/mixed; boundary=\"$mixed\"")
            line()
            line("--$mixed")
        }
        line("Content-Type: multipart/alternative; boundary=\"$alt\"")
        line()
        line("--$alt")
        line("Content-Type: text/plain; charset=UTF-8")
        line("Content-Transfer-Encoding: base64")
        line()
        line(mimeB64(text.replace("\r\n", "\n").replace("\n", "\r\n").toByteArray(Charsets.UTF_8)))
        line("--$alt")
        line("Content-Type: text/html; charset=UTF-8")
        line("Content-Transfer-Encoding: base64")
        line()
        line(mimeB64(html.toByteArray(Charsets.UTF_8)))
        line("--$alt--")
        if (attachments.isNotEmpty()) {
            for (a in attachments) {
                line("--$mixed")
                line("Content-Type: ${a.mime}; name=\"${a.name}\"")
                line("Content-Transfer-Encoding: base64")
                line("Content-Disposition: attachment; filename=\"${a.name}\"")
                line()
                line(mimeB64(a.bytes))
            }
            sb.append("--$mixed--")
        }
        return sb.toString()
    }
}
