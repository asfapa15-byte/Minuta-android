package ro.alex.minuta

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.PackageManager
import android.provider.CalendarContract
import androidx.core.content.ContextCompat

data class CalEvent(
    val id: Long,
    val title: String,
    val begin: Long,
    val end: Long,
    /** Guests: name -> e-mail (name falls back to the part before @). */
    val guests: LinkedHashMap<String, String>,
)

/** Reads meetings from the phone's calendars (Google, Outlook/Exchange, Samsung…), read-only. */
object CalendarHelper {

    fun hasPermission(ctx: Context) =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CALENDAR) == PackageManager.PERMISSION_GRANTED

    fun events(ctx: Context, from: Long, to: Long): List<CalEvent> {
        if (!hasPermission(ctx)) return emptyList()
        val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(builder, from)
        ContentUris.appendId(builder, to)
        val projection = arrayOf(
            CalendarContract.Instances.EVENT_ID,
            CalendarContract.Instances.TITLE,
            CalendarContract.Instances.BEGIN,
            CalendarContract.Instances.END,
            CalendarContract.Instances.ALL_DAY,
        )
        val out = mutableListOf<CalEvent>()
        try {
            ctx.contentResolver.query(builder.build(), projection, null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
                while (c.moveToNext()) {
                    if (c.getInt(4) == 1) continue
                    val id = c.getLong(0)
                    out.add(CalEvent(id, c.getString(1).orEmpty(), c.getLong(2), c.getLong(3), guests(ctx, id)))
                }
            }
        } catch (e: Exception) {
            // Some calendar providers misbehave; treat as no events.
        }
        return out.distinctBy { it.id to it.begin }
    }

    private fun guests(ctx: Context, eventId: Long): LinkedHashMap<String, String> {
        val map = LinkedHashMap<String, String>()
        try {
            ctx.contentResolver.query(
                CalendarContract.Attendees.CONTENT_URI,
                arrayOf(
                    CalendarContract.Attendees.ATTENDEE_NAME,
                    CalendarContract.Attendees.ATTENDEE_EMAIL,
                    CalendarContract.Attendees.ATTENDEE_TYPE,
                ),
                "${CalendarContract.Attendees.EVENT_ID}=?",
                arrayOf(eventId.toString()),
                null,
            )?.use { c ->
                while (c.moveToNext()) {
                    if (c.getInt(2) == CalendarContract.Attendees.TYPE_RESOURCE) continue
                    val mail = c.getString(1).orEmpty().trim()
                    if (!mail.contains('@')) continue
                    val name = c.getString(0).orEmpty().trim().ifEmpty { mail.substringBefore('@') }
                    map[name] = mail
                }
            }
        } catch (e: Exception) {
            // Ignore guests we can't read.
        }
        return map
    }

    /** The meeting happening now, or the next one starting within 30 minutes. */
    fun current(ctx: Context): CalEvent? {
        val now = System.currentTimeMillis()
        val list = events(ctx, now - 4 * 3600_000L, now + 30 * 60_000L)
            .filter { it.end > now - 5 * 60_000L && it.begin < now + 30 * 60_000L }
        return list.filter { it.begin <= now }.maxByOrNull { it.begin } ?: list.minByOrNull { it.begin }
    }

    /** Today's meetings from 3 hours ago until midnight. */
    fun today(ctx: Context): List<CalEvent> {
        val now = System.currentTimeMillis()
        val end = java.util.Calendar.getInstance().apply {
            set(java.util.Calendar.HOUR_OF_DAY, 23)
            set(java.util.Calendar.MINUTE, 59)
        }.timeInMillis
        return events(ctx, now - 3 * 3600_000L, end)
    }
}
