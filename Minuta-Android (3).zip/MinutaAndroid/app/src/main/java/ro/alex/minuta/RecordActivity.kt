package ro.alex.minuta

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.launch
import java.io.File

class RecordActivity : LockedActivity() {

    companion object {
        const val ACTION_QUICK_START = "ro.alex.minuta.QUICK_START"
    }

    private lateinit var titleField: TextInputEditText
    private lateinit var peopleField: TextInputEditText
    private lateinit var recipientsField: TextInputEditText
    private lateinit var calendarNote: TextView
    private lateinit var spokenGroup: MaterialButtonToggleGroup
    private lateinit var minuteGroup: MaterialButtonToggleGroup
    private lateinit var timer: TextView
    private lateinit var stateText: TextView
    private lateinit var startBtn: MaterialButton
    private lateinit var controls: View
    private lateinit var pauseBtn: MaterialButton
    private lateinit var photoBtn: MaterialButton
    private lateinit var photoCount: TextView
    private lateinit var mainHint: TextView
    private lateinit var waveform: WaveformView
    private lateinit var pulse: View
    private var pulseAnim: android.animation.ValueAnimator? = null
    private val meterHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val meterTick = object : Runnable {
        override fun run() {
            val s = RecordingService.state.value
            val live = s.meetingId != null && !s.paused
            waveform.setActive(live)
            if (live) waveform.push(RecordingService.amplitude)
            meterHandler.postDelayed(this, 80)
        }
    }
    private var shownId: String? = null
    private var calendarContacts: Map<String, String> = emptyMap()
    private var pendingPhoto: File? = null
    private var quickStart = false

    private val permissions = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (hasMic()) begin()
        else Toast.makeText(this, "Fără acces la microfon nu pot înregistra.", Toast.LENGTH_LONG).show()
    }

    private val calendarPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) chooseFromCalendar()
        else Toast.makeText(this, "Fără acces la calendar nu pot prelua ședința.", Toast.LENGTH_LONG).show()
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = pendingPhoto ?: return@registerForActivityResult
        val id = RecordingService.state.value.meetingId ?: shownId ?: return@registerForActivityResult
        pendingPhoto = null
        if (Photos.keep(this, id, f, ok)) Toast.makeText(this, "Poză adăugată la ședință", Toast.LENGTH_SHORT).show()
        updatePhotoCount()
    }

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val id = RecordingService.state.value.meetingId ?: shownId
        if (uri != null && id != null) {
            if (Photos.import(this, id, uri)) Toast.makeText(this, "Poză adăugată la ședință", Toast.LENGTH_SHORT).show()
            updatePhotoCount()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_record)
        val toolbar = findViewById<MaterialToolbar>(R.id.toolbar)
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        toolbar.setNavigationOnClickListener { finish() }

        titleField = findViewById(R.id.title)
        peopleField = findViewById(R.id.participants)
        recipientsField = findViewById(R.id.recipients)
        calendarNote = findViewById(R.id.calendar_note)
        spokenGroup = findViewById(R.id.spoken_lang)
        minuteGroup = findViewById(R.id.minute_lang)
        timer = findViewById(R.id.timer)
        stateText = findViewById(R.id.state)
        startBtn = findViewById(R.id.start)
        controls = findViewById(R.id.controls)
        pauseBtn = findViewById(R.id.pause)
        photoBtn = findViewById(R.id.photo_camera)
        photoCount = findViewById(R.id.photo_count)
        mainHint = findViewById(R.id.main_hint)
        waveform = findViewById(R.id.waveform)
        pulse = findViewById(R.id.pulse)

        val recipientsLayout = findViewById<TextInputLayout>(R.id.recipients_layout)
        if (Mailer.ready(this)) {
            if (savedInstanceState == null) recipientsField.setText(Prefs.raw(this, "last_recipients"))
        } else {
            recipientsLayout.visibility = View.GONE
        }

        spokenGroup.check(
            when (Prefs.defaultSpokenLang(this)) {
                "en" -> R.id.spoken_en
                "auto" -> R.id.spoken_auto
                else -> R.id.spoken_ro
            }
        )
        minuteGroup.check(if (Prefs.defaultMinuteLang(this) == "en") R.id.minute_en else R.id.minute_ro)

        findViewById<MaterialButton>(R.id.calendar_btn).setOnClickListener {
            if (CalendarHelper.hasPermission(this)) chooseFromCalendar()
            else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
        }
        startBtn.setOnClickListener {
            Ui.confirm(it)
            if (RecordingService.state.value.meetingId != null) stopAndOpen() else requestAndStart()
        }
        pauseBtn.setOnClickListener {
            Ui.tick(it)
            val action = if (RecordingService.state.value.paused) RecordingService.ACTION_RESUME
            else RecordingService.ACTION_PAUSE
            RecordingService.send(this, action)
        }
        photoBtn.setOnClickListener {
            Ui.tick(it)
            capturePhoto()
        }
        spokenGroup.addOnButtonCheckedListener { g, _, checked -> if (checked) Ui.tick(g) }
        minuteGroup.addOnButtonCheckedListener { g, _, checked -> if (checked) Ui.tick(g) }
        findViewById<MaterialButton>(R.id.photo_gallery).setOnClickListener {
            pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }

        // Fill in from the meeting happening now, if the calendar is allowed.
        if (savedInstanceState == null && RecordingService.state.value.meetingId == null && CalendarHelper.hasPermission(this)) {
            CalendarHelper.current(this)?.let { fill(it) }
        }
        quickStart = savedInstanceState == null && intent?.action == ACTION_QUICK_START

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { RecordingService.state.collect { render(it) } }
                launch { MeetingRepo.changes.collect { render(RecordingService.state.value) } }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_QUICK_START && RecordingService.state.value.meetingId == null) requestAndStart()
    }

    override fun onStart() {
        super.onStart()
        meterHandler.post(meterTick)
    }

    override fun onStop() {
        meterHandler.removeCallbacks(meterTick)
        setPulse(false)
        super.onStop()
    }

    /** Soft red halo breathing around the button while recording. */
    private fun setPulse(on: Boolean) {
        if (on) {
            if (pulseAnim != null) return
            pulseAnim = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1400
                repeatCount = android.animation.ValueAnimator.INFINITE
                interpolator = android.view.animation.DecelerateInterpolator()
                addUpdateListener { a ->
                    val f = a.animatedValue as Float
                    pulse.scaleX = 0.78f + 0.22f * f
                    pulse.scaleY = 0.78f + 0.22f * f
                    pulse.alpha = 0.32f * (1f - f)
                }
                start()
            }
        } else {
            pulseAnim?.cancel()
            pulseAnim = null
            pulse.alpha = 0f
        }
    }

    override fun onResume() {
        super.onResume()
        if (quickStart) {
            quickStart = false
            if (RecordingService.state.value.meetingId == null) requestAndStart()
        }
    }

    // ---------------------------------------------------------------- calendar

    private fun chooseFromCalendar() {
        val events = CalendarHelper.today(this)
        if (events.isEmpty()) {
            Toast.makeText(this, "Nu găsesc ședințe azi în calendar.", Toast.LENGTH_LONG).show()
            return
        }
        val labels = events.map { "${Format.time(it.begin)}–${Format.time(it.end)}  ${it.title.ifBlank { "(fără titlu)" }}" }
        MaterialAlertDialogBuilder(this)
            .setTitle("Alege ședința")
            .setItems(labels.toTypedArray()) { _, which -> fill(events[which]) }
            .setNegativeButton("Renunță", null)
            .show()
    }

    private fun fill(e: CalEvent) {
        if (e.title.isNotBlank()) titleField.setText(e.title)
        if (e.guests.isNotEmpty()) {
            peopleField.setText(e.guests.keys.joinToString(", "))
            if (Mailer.ready(this)) recipientsField.setText(e.guests.values.joinToString(", "))
        }
        calendarContacts = e.guests
        calendarNote.text = "Completat din calendar: ${e.title.ifBlank { "ședință" }} (${Format.time(e.begin)}–${Format.time(e.end)}). " +
            "Verifică destinatarii înainte de trimitere."
        calendarNote.visibility = View.VISIBLE
    }

    // ---------------------------------------------------------------- photos

    private fun capturePhoto() {
        val id = RecordingService.state.value.meetingId ?: return
        val f = Photos.newFile(this, id)
        pendingPhoto = f
        try {
            takePhoto.launch(Photos.uriFor(this, f))
        } catch (e: Exception) {
            pendingPhoto = null
            Toast.makeText(this, "Nu am găsit o aplicație de cameră.", Toast.LENGTH_LONG).show()
        }
    }

    private fun updatePhotoCount() {
        val id = RecordingService.state.value.meetingId ?: shownId
        val n = id?.let { MeetingRepo.get(this, it)?.photos?.size } ?: 0
        photoCount.text = when (n) {
            0 -> "Pozele cu tabla sau slide-urile sunt citite de AI și incluse în minută."
            1 -> "1 poză adăugată"
            else -> "$n poze adăugate"
        }
    }

    // ---------------------------------------------------------------- recording

    private fun hasMic() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) ==
        PackageManager.PERMISSION_GRANTED

    private fun requestAndStart() {
        val needed = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) begin() else permissions.launch(missing.toTypedArray())
    }

    private fun recipients(): String? {
        val text = recipientsField.text?.toString().orEmpty().trim()
        val bad = Mailer.invalidAddresses(text)
        if (bad.isNotEmpty()) {
            recipientsField.error = "Adresă greșită: ${bad.joinToString()}"
            return null
        }
        recipientsField.error = null
        return Mailer.parseAddresses(text).joinToString(", ")
    }

    private fun spokenLang() = when (spokenGroup.checkedButtonId) {
        R.id.spoken_en -> "en"
        R.id.spoken_auto -> "auto"
        else -> "ro"
    }

    private fun minuteLang() = if (minuteGroup.checkedButtonId == R.id.minute_en) "en" else "ro"

    private fun begin() {
        if (RecordingService.state.value.meetingId != null) return
        val to = recipients() ?: return
        val m = Meeting(
            MeetingRepo.newId(),
            titleField.text?.toString().orEmpty().trim(),
            peopleField.text?.toString().orEmpty().trim(),
            System.currentTimeMillis(),
        )
        m.status = Status.RECORDING
        m.emailTo = to
        m.spokenLang = spokenLang()
        m.minuteLang = minuteLang()
        m.contacts.putAll(calendarContacts)
        if (to.isNotEmpty()) Prefs.save(this, mapOf("last_recipients" to to))
        MeetingRepo.save(this, m)
        shownId = m.id
        RecordingService.send(this, RecordingService.ACTION_START, m.id)
        startBtn.isEnabled = false
        stateText.text = "Pornesc microfonul…"
    }

    private fun stopAndOpen() {
        val id = RecordingService.state.value.meetingId ?: return
        // Stopping must always work: wrong addresses are simply dropped here.
        val text = recipientsField.text?.toString().orEmpty()
        val bad = Mailer.invalidAddresses(text)
        val to = Mailer.parseAddresses(text).filter { it !in bad }.joinToString(", ")
        if (to.isNotEmpty()) Prefs.save(this, mapOf("last_recipients" to to))
        MeetingRepo.update(this, id) {
            it.title = titleField.text?.toString().orEmpty().trim()
            it.participants = peopleField.text?.toString().orEmpty().trim()
            it.emailTo = to
            it.spokenLang = spokenLang()
            it.minuteLang = minuteLang()
            if (calendarContacts.isNotEmpty()) it.contacts.putAll(calendarContacts)
        }
        RecordingService.send(this, RecordingService.ACTION_STOP)
        startActivity(MinuteActivity.intent(this, id))
        finish()
    }

    private fun render(s: RecordingService.RecState) {
        val recording = s.meetingId != null
        if (recording && shownId != s.meetingId) {
            // Came back to a recording already running: show its fields.
            shownId = s.meetingId
            MeetingRepo.get(this, s.meetingId!!)?.let {
                titleField.setText(it.title)
                peopleField.setText(it.participants)
                recipientsField.setText(it.emailTo)
                spokenGroup.check(
                    when (it.spokenLang) {
                        "en" -> R.id.spoken_en
                        "auto" -> R.id.spoken_auto
                        else -> R.id.spoken_ro
                    }
                )
                minuteGroup.check(if (it.minuteLang == "en") R.id.minute_en else R.id.minute_ro)
                calendarContacts = it.contacts
            }
        }
        if (recording) startBtn.isEnabled = true
        controls.visibility = if (recording) View.VISIBLE else View.GONE
        pauseBtn.visibility = if (recording) View.VISIBLE else View.INVISIBLE
        photoBtn.visibility = if (recording) View.VISIBLE else View.INVISIBLE
        startBtn.setIconResource(if (recording) R.drawable.ic_stop else R.drawable.ic_mic)
        startBtn.contentDescription = if (recording) "Oprește și fă minuta" else "Pornește înregistrarea"
        pauseBtn.setIconResource(if (s.paused) R.drawable.ic_play else R.drawable.ic_pause)
        pauseBtn.contentDescription = if (s.paused) "Continuă" else "Pauză"
        mainHint.text = when {
            !recording -> "Atinge ca să începi"
            s.paused -> "În pauză · atinge ■ ca să oprești"
            else -> "Atinge ■ ca să oprești și să faci minuta"
        }
        timer.setTextColor(ContextCompat.getColor(this, if (recording && !s.paused) R.color.accent else R.color.ink))
        setPulse(recording && !s.paused)
        timer.text = Format.duration(s.elapsedMs)
        if (recording) {
            stateText.text = if (s.paused) "În pauză" else "Se înregistrează. Poți stinge ecranul."
            updatePhotoCount()
        } else if (startBtn.isEnabled) {
            stateText.text = "Gata de înregistrare"
        } else if (shownId != null) {
            // The service refused to start (e.g. microphone busy).
            MeetingRepo.get(this, shownId!!)?.takeIf { it.status == Status.ERROR }?.let {
                stateText.text = it.error ?: "Nu am putut porni înregistrarea."
                startBtn.isEnabled = true
                shownId = null
            }
        }
    }
}
