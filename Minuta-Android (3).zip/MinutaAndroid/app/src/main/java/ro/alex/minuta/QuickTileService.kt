package ro.alex.minuta

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Quick Settings button: one tap opens Minuta and starts recording. */
class QuickTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        val tile = qsTile ?: return
        val recording = RecordingService.state.value.meetingId != null
        tile.state = if (recording) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = if (recording) "Se înregistrează" else "Minuta"
        if (Build.VERSION.SDK_INT >= 29) tile.subtitle = if (recording) "Atinge pentru detalii" else "Ședință nouă"
        tile.updateTile()
    }

    override fun onClick() {
        super.onClick()
        if (isLocked) unlockAndRun { launch() } else launch()
    }

    private fun launch() {
        val intent = Intent(this, RecordActivity::class.java)
            .setAction(RecordActivity.ACTION_QUICK_START)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        if (Build.VERSION.SDK_INT >= 34) {
            startActivityAndCollapse(
                PendingIntent.getActivity(this, 11, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            )
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    companion object {
        /** Asks the system to refresh the tile (recording started/stopped). */
        fun refresh(ctx: Context) {
            try {
                requestListeningState(ctx, ComponentName(ctx, QuickTileService::class.java))
            } catch (e: Exception) {
                // Tile not added; nothing to refresh.
            }
        }
    }
}
