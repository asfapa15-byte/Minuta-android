package ro.alex.minuta

import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK
import androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton

class LockActivity : AppCompatActivity() {

    private var prompting = false
    private var autoPrompted = false
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLock.showing = true
        setContentView(R.layout.activity_lock)
        status = findViewById(R.id.lock_status)
        findViewById<MaterialButton>(R.id.unlock).setOnClickListener { prompt() }
        // Back from the lock screen leaves the app (a recording keeps going in the background).
        onBackPressedDispatcher.addCallback(this) { finishAffinity() }
    }

    override fun onResume() {
        super.onResume()
        if (AppLock.unlocked) {
            finish()
        } else if (!autoPrompted) {
            autoPrompted = true
            prompt()
        }
    }

    private fun prompt() {
        if (prompting) return
        if (!AppLock.available(this)) {
            // The phone's screen lock was removed: nothing to check against.
            AppLock.unlocked = true
            finish()
            return
        }
        prompting = true
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                prompting = false
                AppLock.unlocked = true
                finish()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                prompting = false
                status.text = errString
            }
        }
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Deblochează Minuta")
            .setSubtitle("Amprentă, față sau PIN-ul telefonului")
        if (Build.VERSION.SDK_INT >= 30) {
            builder.setAllowedAuthenticators(BIOMETRIC_WEAK or DEVICE_CREDENTIAL)
        } else {
            @Suppress("DEPRECATION")
            builder.setDeviceCredentialAllowed(true)
        }
        BiometricPrompt(this, ContextCompat.getMainExecutor(this), callback).authenticate(builder.build())
    }

    override fun onDestroy() {
        AppLock.showing = false
        super.onDestroy()
    }
}
