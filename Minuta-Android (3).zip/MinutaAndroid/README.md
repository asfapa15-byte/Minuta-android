# Minuta – aplicație Android pentru minute de ședință

Aplicația înregistrează ședința prin microfonul telefonului, transcrie discuția în română și scrie minuta:
**rezumat, decizii, acțiuni (cu responsabil și termen) și transcrierea completă**.

## Ce face

- Înregistrează în fundal, inclusiv cu ecranul stins. Are pauză/continuare și butoane direct în notificare.
- Taie automat audio în bucăți de 10 minute, așa că merge și la ședințe de câteva ore.
- Transcrie în română și scrie minuta, gratuit prin Gemini sau Groq ori, cu plată, prin OpenAI + Claude. Transformă termenele relative („vineri”) în date concrete.
- Poate importa înregistrări existente (meniul ⋮ → *Importă înregistrare*), de exemplu apelurile înregistrate de telefoanele Samsung sau un fișier .m4a/.mp3 trimis de cineva.
- Poți trimite minuta pe e-mail, Teams sau WhatsApp (butonul *Trimite*), o poți copia sau regenera.
- Păstrează istoricul ședințelor pe telefon. Dacă transcrierea se întrerupe (de exemplu fără internet), *Reîncearcă* reia de unde a rămas.

## Noutăți în versiunea 1.6

- **Widget pe ecranul principal.** Ține apăsat pe ecranul principal → Widgeturi → Minuta. Din widget pornești o ședință dintr-o atingere, vezi cronometrul cât înregistrezi, următoarele 3 acțiuni cu termene și câte minute așteaptă verificarea. Dacă blocarea e activă, widgetul nu afișează detalii.
- **Notificări reparate.** Permisiunea se cere la prima deschidere. Dacă notificările sunt oprite, pe ecranul principal apare un mesaj. În Setări → Notificări ai un buton de test.

## Noutăți în versiunea 1.5 – design nou

- **Culori grafit și roșu**, potrivite cu iconița M, în modurile zi și noapte.
- **Bară de navigare jos:** Ședințe · Acțiuni · Setări.
- **Carduri:** fiecare ședință are data, durata și o etichetă colorată cu starea („De verificat și trimis”, „2 acțiuni deschise”, „✓ Gata”).
- **Glisare:** pe Ședințe, glisezi spre stânga ca să ștergi (cu „Anulează”). Pe Acțiuni, glisezi spre dreapta ca să bifezi.
- **Înregistrare:** buton mare și rotund cu halou animat, undă sonoră live, butoane rotunde pentru pauză și poză.
- **Animații și vibrații:** tranziții între ecrane, carduri care apar animat, vibrație la pornire, oprire și bifare.

## Noutăți în versiunea 1.4

- **Calendar:** la „Ședință nouă” se completează singure subiectul, participanții și destinatarii din ședința care are loc acum. Altă ședință din ziua respectivă o alegi cu butonul „Ia datele din calendar”.
- **Verificare înainte de trimitere** (pornită implicit): minuta așteaptă să o verifici și să o editezi, apoi o trimiți cu „Trimite acum”.
- **Buton rapid:** trage de două ori în jos bara de notificări, apasă ✎ (editare) și adaugă dala „Minuta”. O atingere pornește înregistrarea.
- **Engleză:** alegi limba vorbită (română, engleză sau mixt) și limba minutei.
- **Acțiuni deschise:** ⋮ → Acțiuni deschise. Le bifezi când sunt gata și primești dimineața notificări pentru termenele apropiate.
- **E-mail profesionist:** expeditorul „Minută ședință”, răspunsurile ajung la adresa ta, semnătură, PDF atașat.
- **Sarcini pe persoană și rezumat săptămânal:** fiecare responsabil își primește acțiunile pe e-mail, iar lunea primești rezumatul acțiunilor deschise.
- **Poze cu tabla sau slide-ul:** în timpul înregistrării sau după aceea. AI-ul le citește și le include în minută (cu Gemini sau Premium).
- **Căutare** în toate ședințele (lupa de pe ecranul principal).

## Blocare și e-mail (versiunea 1.3)

- **Blocare:** ⋮ → Setări → *Securitate*. Aplicația cere amprenta, fața sau PIN-ul telefonului la deschidere și după 1 minut în fundal.
- **Trimitere automată pe e-mail:** ⋮ → Setări → *Trimitere automată pe e-mail*. Ai nevoie de adresa ta Gmail și de o **parolă de aplicație** de la <https://myaccount.google.com/apppasswords>, iar contul trebuie să aibă verificarea în doi pași activă. Destinatarii îi alegi la fiecare ședință, iar ultimii folosiți sunt completați automat. Minuta pleacă singură imediat ce e gata. O poți retrimite oricând din meniul ședinței.

## Ce îți trebuie

Alegi serviciul în ⋮ → **Setări**:

- **Gratuit – Google Gemini (implicit).** Te conectezi cu contul Google pe <https://aistudio.google.com/apikey> → *Create API key*. Gemini face și transcrierea, și minuta. Pe planul gratuit, Google poate folosi datele trimise ca să-și îmbunătățească produsele.
- **Gratuit – Groq.** Cheie de pe <https://console.groq.com/keys>. Transcrierea se face cu Whisper, iar minuta cu un model open-source.
- **Premium (cu plată).** OpenAI pentru transcriere și Claude pentru minută.

## Cum obții APK-ul

### Varianta A – fără să instalezi nimic (GitHub)
1. Fă-ți un cont gratuit pe <https://github.com> și creează un repository nou (poate fi privat).
2. Urcă tot conținutul acestui folder: *Add file → Upload files*, apoi trage fișierele și folderele, inclusiv folderul `.github`.
3. Mergi în tab-ul **Actions**. Build-ul pornește singur și durează cam 5 minute.
4. Când apare bifa verde, deschide rularea și descarcă **Minuta-apk** de la *Artifacts*.
5. Pe telefon: dezarhivează, deschide `app-debug.apk` și permite instalarea din surse necunoscute.

> Dacă browserul nu urcă folderul `.github` (e ascuns), creează-l manual: *Add file → Create new file*, cu numele `.github/workflows/build.yml`, și copiază conținutul fișierului.

### Varianta B – Android Studio
1. Instalează Android Studio, apoi *Open* → alege acest folder.
2. Așteaptă sincronizarea Gradle.
3. Conectează telefonul (cu *USB debugging* activ) și apasă ▶ Run.

## Bine de știut

- **Apeluri Teams / telefon:** Android nu permite aplicațiilor să înregistreze direct sunetul unui apel. Pune apelul pe difuzor lângă telefon sau importă înregistrarea făcută de aplicația de telefon.
- **Baterie:** la unele telefoane (Samsung, Xiaomi) setează *Baterie → Fără restricții* pentru Minuta, ca sistemul să nu oprească înregistrările lungi.
- **Confidențialitate:** audio și transcrierile rămân pe telefon. Audio și textul ajung doar la serviciul ales în Setări (Google, Groq sau OpenAI și Anthropic). Verifică dacă politica firmei permite folosirea acestor servicii pentru ședințele respective.
- **Legal:** anunță participanții că ședința este înregistrată.

## Structura codului

| Fișier | Rol |
|---|---|
| `RecordingService.kt` | Înregistrarea în fundal (serviciu foreground), segmente de 10 min, notificări |
| `Processor.kt` | Transcriere pe segmente + cererea către Claude pentru minută |
| `Api.kt` | Apelurile HTTP către OpenAI și Anthropic, cu reîncercări |
| `Importer.kt` | Importul fișierelor audio și tăierea celor mari |
| `MainActivity.kt` / `RecordActivity.kt` / `MinuteActivity.kt` / `SettingsActivity.kt` | Ecranele |
